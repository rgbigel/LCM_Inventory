# DeviceInventory Repository — Action List

**Version:** 0.1.0  
**Status:** Repository initialized  
**Priority:** MEDIUM (consolidate with VolumeInventory)

---

## 📋 PROJECT OVERVIEW

Device and volume enumeration utilities:
- `Get-DevicePath-from-DeviceName.ps1` — Map device name to path
- `List-Device-Name-and-Path.ps1` — List all devices
- `DiskInfo.cmd` — WMIC-based volume info

---

## 🔧 KEY ACTIONS

### Important Note: VolumeInventory Consolidation
- **DEFER:** Full integration with existing VolumeInventory repository
- **Action:** Review VolumeInventory first to avoid duplication
- **Opportunity:** These utilities may belong WITH VolumeInventory, not separate

### Module Extraction (Conditional)
- [ ] **DeviceEnumeration.psm1** → WMI/device queries
  - Functions: `Get-AllDevices()`, `Get-DevicesByType()`, `Get-DevicePath()`

- [ ] **VolumeTools.psm1** → Volume-specific operations
  - Coordinate with VolumeInventory existing code
  - Functions: `Get-VolumeInfo()`, `Get-VolumeCapacity()`, `Test-VolumeAccessible()`

### Source Script Analysis
- [ ] Review VolumeInventory project structure
- [ ] Identify overlaps with existing code
- [ ] Decide: Merge into VolumeInventory or keep separate?

### Installer
- [ ] Create `Install/DeviceInventory_Install.ps1`
- [ ] Validate WMI access
- [ ] Test on different Windows versions

---

## 🎯 DECISION TREE

**Question 1:** Does VolumeInventory already have device enumeration?
- If YES → Merge DeviceInventory into VolumeInventory
- If NO → Proceed with standalone DeviceInventory

**Question 2:** Is there value in separate DeviceInventory vs integrated?
- Separate: Simpler module, focused on devices
- Integrated: Single source of truth for all inventory

---

## ⏱️ ESTIMATED EFFORT
- Content review + analysis: 2-3 hours
- Consolidation decision: 1 hour
- Implementation (if separate): 4-6 hours

---

**Status:** DEFERRED pending VolumeInventory review
