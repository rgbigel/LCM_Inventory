# CommandHub Repository — Action List

**Version:** 0.1.0  
**Status:** Repository initialized, foundation file added  
**Priority:** MEDIUM-HIGH (foundation for StartAnything feature request)

---

## 📋 PROJECT VISION

**Goal:** Create universal command launcher that:
1. Finds executables anywhere on system via Everything search (es.exe)
2. Supports all file types: .cmd, .ps1, .exe, .dll, .bat, .msi
3. Handles multiple matches with interactive selection
4. Passes parameters to target executable
5. Runs with elevation when requested
6. Respects user search volume preferences

**Status:** Currently have `elsewhere-starter.cmd` as proof-of-concept using `runas.exe + es.exe`

---

## 📝 STRUCTURAL CONFORMANCE CHECKLIST

- [ ] **README.md** → Project overview and feature list
- [ ] **LICENSE** → Add (consistent with workspace)
- [ ] **.gitignore** → Add logs/, cache/, temp/ patterns
- [ ] **SPECIFICATION.md** → Complete user requirements document
- [ ] **CHANGELOG.md** → Version history

---

## 🔧 MODULARIZATION CHECKLIST

### Phase 1: Create Core Modules

#### Module: `Modules/CommandLocator.psm1` (NEW)
**Purpose:** Locate executables via Everything search (es.exe)  
**Functions:**
- [ ] `Find-Command()` → Search for command by name using es.exe
- [ ] `Test-EverythingAvailable()` → Check if es.exe is installed
- [ ] `Get-SearchPath()` → Resolve search path from user preferences
- [ ] `Format-SearchResults()` → Display results for user selection

**Design Details:**
- **Dependency:** Requires es.exe (Everything CLI) at `C:\Program Files\Everything\es.exe` or custom path
- **Search Scope:** Default C:\ and D:\ (overridable)
- **Match Handling:** 
  - Single match: Execute directly
  - Multiple matches: Show list, wait for selection
  - No match: Report error

**Contract Surface:**
```
Export-ModuleMember -Function @(
    'Find-Command'
    'Test-EverythingAvailable'
    'Get-SearchPath'
    'Format-SearchResults'
)
```

**Implementation Notes:**
```powershell
# es.exe usage examples:
# es.exe -nocase "filename.exe"  → Find by name (case-insensitive)
# es.exe -regex "^[cd]:" → Filter by volume
# es.exe -ext exe,cmd,ps1 → Filter by extension
```

---

#### Module: `Modules/CommandExecutor.psm1` (NEW)
**Purpose:** Execute commands with parameters and elevation support  
**Functions:**
- [ ] `Invoke-Command()` → Run command with optional parameters
- [ ] `Invoke-ElevatedCommand()` → Run command as Administrator
- [ ] `Test-CommandAccessible()` → Check if file is executable
- [ ] `Add-ToCommandCache()` → Save recent command for quick re-run
- [ ] `Get-FromCommandCache()` → Retrieve cached command

**Design Details:**
- **Parameter Passing:** Support quoted arguments with spaces
- **Elevation:** Use `Start-Process -Verb RunAs` or runas.exe
- **Async Execution:** Options to wait or detach from launcher
- **Error Handling:** Capture and report execution errors

**Contract Surface:**
```
Export-ModuleMember -Function @(
    'Invoke-Command'
    'Invoke-ElevatedCommand'
    'Test-CommandAccessible'
    'Add-ToCommandCache'
    'Get-FromCommandCache'
)
```

---

#### Module: `Modules/CommandCache.psm1` (NEW)
**Purpose:** Cache frequently used commands for quick access  
**Functions:**
- [ ] `Initialize-CommandCache()` → Create cache file/structure
- [ ] `Save-CommandInCache()` → Add command to cache
- [ ] `Get-CachedCommands()` → List recent commands
- [ ] `Clear-CommandCache()` → Wipe cache
- [ ] `Test-CacheValid()` → Verify cached paths still exist

**Storage Format:** JSON file at `%APPDATA%\CommandHub\cache.json`

```json
{
  "version": "1.0",
  "lastUpdated": "2026-06-23T12:34:56Z",
  "commands": [
    {
      "name": "PowerShell",
      "path": "C:\\Program Files\\PowerShell\\7\\pwsh.exe",
      "count": 15,
      "lastUsed": "2026-06-23T12:34:56Z"
    }
  ]
}
```

---

#### Module: `Modules/CommandConfiguration.psm1` (NEW)
**Purpose:** Load/save user preferences and settings  
**Functions:**
- [ ] `Get-CommandHubConfig()` → Load user configuration
- [ ] `Set-CommandHubConfig()` → Save user configuration
- [ ] `Get-DefaultSearchVolumes()` → Return configured search volumes
- [ ] `Get-EverythingPath()` → Return custom es.exe path if configured
- [ ] `Test-ConfigValid()` → Validate configuration

**Config File:** `%APPDATA%\CommandHub\config.json`

```json
{
  "searchVolumes": ["C:", "D:"],
  "everythingPath": "C:\\Program Files\\Everything\\es.exe",
  "cacheEnabled": true,
  "elevationPrompt": true,
  "defaultExtensions": ["exe", "cmd", "ps1"]
}
```

---

### Phase 2: Create Source Scripts

#### Source: `Source/Start-Command.ps1` (NEW)
**Purpose:** Interactive PowerShell-based command launcher (modern interface)  
**Actions:**
- [ ] Create function `Start-Command()` with parameters:
  - [ ] `-CommandName` (required, or search for it)
  - [ ] `-Parameters` (optional, pass to target)
  - [ ] `-Elevated` (run as admin)
  - [ ] `-FromCache` (use cached version)
  - [ ] `-SearchVolumes` (override defaults)

**Implementation Approach:**
```powershell
param(
    [Parameter(Position = 0)]
    [string]$CommandName,
    
    [Parameter(Position = 1)]
    [string[]]$Parameters = @(),
    
    [switch]$Elevated,
    [switch]$FromCache,
    [string[]]$SearchVolumes
)

# 1. Check cache if -FromCache
# 2. Find command via es.exe
# 3. If multiple: show menu, user selects
# 4. Execute with parameters, optionally elevated
```

---

#### Source: `Source/elsewhere-starter.cmd` (EXISTING)
**Actions:**
- [ ] Keep as-is (good example of runas + es.exe pattern)
- [ ] Add comment block explaining usage
- [ ] Link to PowerShell version in documentation

---

### Phase 3: Create Installer

#### Installer: `Install/CommandHub_Install.ps1`
- [ ] Check if Everything (es.exe) is installed
  - [ ] If not: Provide download link + installation instructions
  - [ ] Allow user to specify custom es.exe path
- [ ] Create %APPDATA%\CommandHub directory
- [ ] Initialize config.json with defaults
- [ ] Initialize cache.json (empty)
- [ ] Copy modules to runtime location
- [ ] Create .cmd launcher: `d:\OneDrive\cmd\StartCommand.cmd`
- [ ] Run compatibility checks

---

## 🧪 TESTING CHECKLIST

### Unit Tests
- [ ] Create `Tests/CommandLocator.Tests.ps1`
  - [ ] Test es.exe availability detection
  - [ ] Test search with single result
  - [ ] Test search with multiple results
  - [ ] Test search with no results
  - [ ] Test volume filtering

- [ ] Create `Tests/CommandExecutor.Tests.ps1`
  - [ ] Test normal execution
  - [ ] Test elevated execution (requires elevation)
  - [ ] Test parameter passing with special characters
  - [ ] Test error handling for missing files

- [ ] Create `Tests/CommandCache.Tests.ps1`
  - [ ] Test cache initialization
  - [ ] Test save/retrieve
  - [ ] Test stale path detection
  - [ ] Test cache cleanup

### Integration Tests
- [ ] Full flow: Search → Select → Execute with parameters
- [ ] Elevated execution workflow
- [ ] Cache usage workflow

---

## 📖 DOCUMENTATION CHECKLIST

**File:** `assets/README.md`
- [ ] Project overview and use cases
- [ ] Installation (especially Everything search setup)
- [ ] Quick-start examples
- [ ] Parameter reference
- [ ] Configuration file format
- [ ] Troubleshooting

**File:** `assets/SPECIFICATION.md`
- [ ] Complete StartAnything requirements (from user memory)
- [ ] Feature breakdown
- [ ] Implementation roadmap
- [ ] Known limitations

**File:** `assets/BNF.md` (optional, if design is formal)
- [ ] BNF grammar for command syntax
- [ ] Parameter passing semantics
- [ ] Search expression format

---

## 🔐 COMPLIANCE CHECKLIST

- [ ] All functions use approved verbs (Find-, Get-, Set-, Start-, Test-, Add-, Remove-, Clear-)
- [ ] Proper error handling (don't swallow exceptions)
- [ ] Verbose/debug modes implemented
- [ ] Version tracking
- [ ] Help documentation for all functions

---

## 🎯 ATOMS IDENTIFIED

### Core Atoms (Essential)
1. **Everything CLI Wrapper** → Find commands by name/pattern
   - Used by: CommandLocator.psm1 (core)
   
2. **Elevation Logic** → Run as admin when needed
   - Used by: CommandExecutor.psm1
   - **Coordinate with:** ACLTools/ElevationTools (DRY principle)

3. **Parameter Escaping** → Handle quoted args with spaces
   - Used by: CommandExecutor.psm1

4. **Configuration Management** → Load/save JSON settings
   - Used by: CommandConfiguration.psm1
   - **Potential Reuse:** Any config-driven utility

5. **Command Cache** → JSON-based recent commands storage
   - Used by: CommandCache.psm1
   - **Potential Reuse:** Build history, audit logging

---

## 🔄 DEPENDENCIES & COORDINATION

### External Dependencies
- **Everything Search (es.exe)** — Must be installed
  - Download: https://www.voidtools.com/
  - Default path: `C:\Program Files\Everything\es.exe`
  - Fallback: Allow user-specified path

### Coordination with Other Projects
- **ACLTools** → Share ElevationTools module
- **SharedTools** → Common logging, validation
- **EnvironmentTools** → Come2Me PATH management integration (future)

---

## ⏱️ ESTIMATED EFFORT

**Phase 1 (Modules):**
- CommandLocator: 2-3 hours
- CommandExecutor: 2-3 hours
- CommandCache: 1-2 hours
- CommandConfiguration: 1 hour
- Subtotal: 6-9 hours

**Phase 2 (Source Scripts):**
- Start-Command.ps1: 2-3 hours
- Documentation: 2-3 hours
- Subtotal: 4-6 hours

**Phase 3 (Testing & Installer):**
- Unit tests: 2-3 hours
- Integration tests: 1-2 hours
- Installer: 1-2 hours
- Subtotal: 4-7 hours

**Total: 14-22 hours**

---

## 📋 IMPLEMENTATION ROADMAP

### Milestone 1: MVP (Core Functionality)
- [ ] CommandLocator + CommandExecutor modules
- [ ] Basic Start-Command.ps1 (search + execute)
- [ ] Manual configuration (no GUI)
- **Estimated:** 1 week

### Milestone 2: Caching & Configuration
- [ ] CommandCache + CommandConfiguration modules
- [ ] JSON config file management
- [ ] Command history
- **Estimated:** 1 week

### Milestone 3: Polish & Integration
- [ ] Comprehensive testing
- [ ] Installer script
- [ ] Documentation
- [ ] Integration with SharedTools
- **Estimated:** 1 week

### Milestone 4: GUI (Future)
- [ ] WPF-based command selector
- [ ] Real-time search suggestions
- [ ] Keyboard shortcuts
- **Estimated:** 2 weeks (deferred)

---

## 🚀 SUCCESS CRITERIA

- [ ] User can find and run any .cmd, .ps1, .exe on C: or D: without knowing full path
- [ ] Supports parameters: `StartCommand PowerShell -NoProfile`
- [ ] Handles multiple matches with interactive selection
- [ ] Elevation works: `StartCommand SomeApp -Elevated`
- [ ] Recent commands cached and quickly re-runnable
- [ ] Works on Windows 11 (with or without Windows Terminal)
- [ ] Zero hardcoded paths (fully configurable)

---

**Created:** 2026-06-23  
**Status:** Action list template ready for implementation  
**Dependency:** Awaiting user confirmation on StartAnything feature prioritization
