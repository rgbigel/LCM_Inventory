# Get-RecoveryVolume

**Version:** 1.0.0

## Overview

`Get-RecoveryVolume.ps1` is a Windows PowerShell utility that extracts WinRE (Windows Recovery Environment) recovery partition information from a given mounted system volume.

The script reads `ReAgent.xml` from the Windows System32 Recovery directory, parses the WinRE location metadata, and resolves the physical disk and partition numbers (0-based) that host the recovery environment.

## Purpose

- **Identify recovery partition location** on any Windows system volume
- **Extract disk and partition numbers** for the WinRE recovery partition
- **Validate ReAgent.xml availability** before querying
- **Provide traced output** for diagnostic purposes

## Usage

```powershell
.\Get-RecoveryVolume.ps1 -p C:
.\Get-RecoveryVolume.ps1 -p C: -t
.\Get-RecoveryVolume.ps1 -h
```

### Parameters

| Parameter | Type   | Required | Description |
|-----------|--------|----------|-------------|
| `-p`      | string | Yes      | Path to the mounted volume (e.g., `C:` or `D:\`) |
| `-t`      | switch | No       | Enable trace/diagnostic output |
| `-h`      | switch | No       | Show help and exit |

## Output

### Success Example

```
WinRE Recovery Partition Information
-----------------------------------
ReAgent.xml Path : y:\Windows\System32\Recovery\ReAgent.xml
Source Volume    : y: D4P1-WDB850-Y

Disk / Partition #:    D4P3
```

- **Disk / Partition #:** `DxPy` format where x = disk number (0-based), y = partition number (0-based)
- **Source Volume:** Drive letter and volume label

### Errors

- Exit code 1 if `ReAgent.xml` not found
- Exit code 1 if XML parse fails
- Exit code 1 if WinreLocation node missing
- Exit code 1 if partition cannot be resolved

## Requirements

- Windows PowerShell 5.0+
- Administrator privileges (for `Get-Partition` cmdlet)
- Access to a mounted Windows installation volume

## Deployment

**Source repo:** `d:\Git_Repositories\GetRecoveryVolume`  
**Command line:** `d:\OneDrive\cmd\Get-RecoveryVolume.ps1`

Changes committed in the repo are automatically synced to the command line location via post-commit hook.

## Version History

### 1.0.0 (2026-06-25)

- Initial release
- Reads ReAgent.xml from mounted volumes
- Resolves disk and partition numbers via byte offset lookup
- Outputs recovery partition information in DxPy format
- Trace mode support (`-t` flag)
- Help mode support (`-h` flag)
