# Architecture: Get-RecoveryVolume

## Design Overview

`Get-RecoveryVolume.ps1` is a **single-file utility** with no modular dependencies. It performs one focused task: read ReAgent.xml from a mounted Windows volume, extract WinRE location metadata, and resolve physical disk/partition numbers.

### Why Single-File

- **Scope:** Focused task with minimal logic
- **Deployment:** Simple copy to command line location
- **Dependency management:** No modular dependencies to maintain
- **Portability:** Can be run standalone from any location

---

## Execution Flow

```
INPUT: Volume path (-p) + optional flags (-t, -h)
  │
  ├─ [Help Mode] → Display usage, exit 0
  │
  ├─ [Validation] → Normalize volume path, check ReAgent.xml exists
  │                  (exit 1 if not found)
  │
  ├─ [XML Parse] → Load and parse ReAgent.xml
  │                 (exit 1 if parse fails)
  │
  ├─ [Data Extract] → Read WinreLocation node, get byte offset
  │                    (exit 1 if node missing)
  │
  ├─ [Partition Lookup] → Query all disks, find partition with matching offset
  │                        Convert PartitionNumber from 1-based to 0-based
  │                        (exit 1 if not found)
  │
  ├─ [Volume Info] → Get volume label from source drive letter
  │
  └─ OUTPUT: Disk/Partition numbers in DxPy format
```

---

## Key Implementation Details

### ReAgent.xml Structure

Windows ReAgent.xml format (Windows 10+):

```xml
<?xml version='1.0' encoding='utf-8'?>
<WindowsRE version="2.0">
  <WinreLocation path="\Recovery\WindowsRE" id="0" offset="267182407680" guid="{...}"/>
  <!-- other recovery config elements -->
</WindowsRE>
```

**Key fields:**
- `path`: Relative path (informational only, not used for resolution)
- `id`: NOT the physical disk number; used only for XML structuring
- `offset`: Byte offset on disk where WinRE partition starts (reliable lookup key)

### Disk/Partition Number Resolution

1. **Problem:** `ReAgent.xml` contains byte offset but not physical disk/partition numbers
2. **Solution:** Query all partitions via `Get-Partition`, match by offset
3. **Output format:** `DxPy` where:
   - `x` = `DiskNumber` from Get-Partition (0-based, system-assigned)
   - `y` = `PartitionNumber - 1` (Get-Partition returns 1-based; convert to 0-based)

### Trace Mode (`-t`)

When enabled, outputs diagnostic messages prefixed `[-t]` in DarkGray color:
- XML file location check
- XML load confirmation
- Byte offset value
- Resolved disk/partition numbers

Useful for troubleshooting XML parse issues or unexpected partition lookups.

---

## Error Handling

| Condition | Exit Code | Message |
|-----------|-----------|---------|
| ReAgent.xml not found | 1 | "ReAgent.xml not found at: {path}" |
| XML parse error | 1 | "Failed to parse ReAgent.xml: {error}" |
| WinreLocation node missing | 1 | "WinreLocation node missing in ReAgent.xml" |
| Partition not found | 1 | "No partition found at offset {offset} on any disk" |
| Get-Partition query fails | 1 | "Failed to query partitions: {error}" |
| Success | 0 | Recovery partition info printed to console |

---

## Command Line Synchronization

**Post-commit hook:** `.git/hooks/post-commit`

- **Trigger:** Every commit in the repo
- **Action:** Copies `Source/Get-RecoveryVolume.ps1` → `d:\OneDrive\cmd\Get-RecoveryVolume.ps1`
- **Purpose:** Keep command-line deployment in sync with repo source
- **Future:** Hook will also sync on push to remote

---

## Dependencies

- **Windows PowerShell 5.0+** (built-in on Windows 10+)
- **Get-Partition** cmdlet (requires PowerShell with StorageModule, admin privileges)
- **Get-Volume** cmdlet (same)

---

## Versioning

**Current version:** 1.0.0

Version info stored in:
- Script header comment (`.VERSION`)
- `README.md` (version badge + history)
- `Architecture.md` (this file)

No separate VERSION file; version updates require manual edits to these three locations.

---

## Future Considerations

- **Phase 2:** Multivolume query (batch process multiple volumes, return CSV)
- **Phase 3:** Integration with disk management tools (BCD, partition tables)
- **Remote sync:** Post-push hook to sync back to `d:\OneDrive\cmd\` on remote updates
