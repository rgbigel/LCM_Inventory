# DiskAssignmentStatus.AGENTS.md — Version 2.3.0

## 1. Purpose
Define repository-local agent configuration for DiskAssignmentStatus. Bind agents to workspace rules. Enforce documentation-driven development, regeneration behavior, module architecture, script constraints, and audit requirements.

## 2. Agents
Agent: DOX  
Agent: DOX-Combined-DiskAssignmentStatus  
Agent: REFAC  
Agent: ALIGN  
Agent: CHECK

Agent File: DOX.agent.md  
Agent File: DOX-Combined-DiskAssignmentStatus.agent.md  
Agent File: REFAC.agent.md  
Agent File: ALIGN.agent.md  
Agent File: CHECK.agent.md

Context File: docs/DocContext.json  
Invocation Prefix: @DOX-Combined-DiskAssignmentStatus  
Invocation Prefix: @REFAC  
Invocation Prefix: @ALIGN  
Invocation Prefix: @CHECK

## 3. Documentation Plane
Documentation under docs is authoritative.  
Documentation defines architecture, behavior, evaluation rules, reporting rules, and implementation constraints.  
Documentation must not be regenerated.  
Documentation must not be rewritten except through DOX.  
Documentation must not be patched.  
Code must follow documentation.  
DocContext.json defines the documentation plane.

## 4. Agent Behavior Guarantees
Documentation is authoritative.  
Code must follow documentation.  
Regeneration is patch-based and safe.  
No automatic changes.  
No fallback to outdated repo truth.  
No normalization of documentation lists.  
No reversion of documentation files.  
No invented behavior.

## 5. Commands
scaffold  
@DOX-Combined-DiskAssignmentStatus scaffold

validate  
@DOX-Combined-DiskAssignmentStatus validate

regenerate  
@DOX-Combined-DiskAssignmentStatus regenerate

audit  
@DOX-Combined-DiskAssignmentStatus audit

refac  
@REFAC refac

align  
@ALIGN align

check  
@CHECK check

## 6. Version
Current version: 2.3.0
Future changes must increment version and document the change.
