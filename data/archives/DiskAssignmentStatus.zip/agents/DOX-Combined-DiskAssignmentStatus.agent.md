# DOX-Combined-DiskAssignmentStatus.agent.md — Version 1.0.0

## 1. Purpose
Define deterministic rules for documentation-driven development, module architecture enforcement, regeneration behavior, script constraints, and audit requirements for the DiskAssignmentStatus tool. Bind repository behavior to workspace rules and ensure that documentation remains authoritative.

## 2. Scope
This agent governs documentation, module directories, source files, regeneration proposals, and audit logs within the DiskAssignmentStatus repository. Workspace rules under .github/agents override local rules unless explicitly overridden.

## 3. Documentation Plane
Documentation under docs is authoritative. Documentation defines architecture, behavior, evaluation rules, reporting rules, and implementation constraints. Documentation must not be regenerated. Documentation must not be rewritten. Documentation must not be patched. Code must follow documentation. Documentation must be updated before implementation changes.

## 4. Source of Truth
Documentation is authoritative. Code must conform to documentation. Module paths must match documented architecture. Documentation must not be altered to match code. Documentation must be treated as immutable during regeneration.

## 5. Constraints
Documentation is read-only. Regeneration must not modify documentation. Regeneration must not invent behavior. Regeneration must not guess missing documentation. Regeneration must not normalize documentation lists. Regeneration must not revert documentation files. Regeneration must not fallback to outdated repository truth. Regeneration must not apply changes automatically.

## 6. Module Architecture
Modules are located under Modules. The architecture consists of Discovery, Evaluation, and Reporting. Discovery performs data collection. Evaluation performs rule-based analysis. Reporting produces output. Each layer must contain psm1 modules implementing only the responsibilities of that layer. No layer may contain responsibilities of another layer. Module names and paths must match documentation.

## 7. Script Requirements
The main script DiskAssignmentStatus.ps1 must contain a parameter block. The script header must appear immediately after the parameter block. The script must follow documented parameter behavior for Json, Verbose, t, and l. The script must implement deterministic orchestration only. The script must not contain business logic. The script must call modules according to the documented architecture.

## 8. Regeneration Behavior
Regeneration is patch-based. Regeneration must align implementation with documentation. Regeneration may propose patches to create missing directories, create missing module stubs, update module headers, align script headers with documentation, align parameter blocks with documentation, and align logging and trace behavior with documentation. Regeneration must not modify documentation. Regeneration must not invent behavior. Regeneration must not guess missing documentation.

## 9. Implementation Constraints
Modules must not use backticks. Pipeline variables must be assigned before use. Discovery and Evaluation must not produce output. Evaluation must use pure functions. Reporting must contain output functions only. Behavior must be deterministic. Module headers must follow documented header format.

## 10. Audit Behavior
All agent runs must produce an audit log under docs/agent-runs. Audit logs must include timestamp, assumptions, regeneration plan, dryRun status, and consistency evaluation. Audit logs must not modify documentation.

## 11. Commands
The scaffold command creates missing directories and module stubs according to documentation and DocContext.json. The validate command checks consistency between documentation, module structure, and implementation. The regenerate-code command regenerates code only. The review-docs command produces reports only and must not modify documentation. The audit command produces a full audit log of the current repository state.

## 12. Guarantees
Documentation is authoritative. Code must follow documentation. Regeneration is patch-based and safe. No automatic changes are allowed. No invented behavior is allowed. No modification of documentation is allowed. No fallback to outdated repository truth is allowed.

## 13. Version
Current version is 1.0.0. Future changes must increment the version and document the change.
