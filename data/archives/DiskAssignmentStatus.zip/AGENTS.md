﻿AGENTS.md â€” Version 2.1.0 (FLAT RULE STYLE)

## 1. Purpose
This workspace comprises multiple repositories, which all use a common documentation-driven architecture.
Define repository-local agent configuration.
Bind DiskAssignmentStatus to workspace rule agents.
Enforce documentation-driven development.
Define regeneration, validation, audit, and architecture rules.
Ensure deterministic behavior across modules and scripts.

## 2. Agents
Agents
- DOX
- DOX-Combined-DiskAssignmentStatus

Agent Files
- DOX.agent.md
- DOX-Combined-DiskAssignmentStatus.agent.md

Context File
- DocContext.json

Invocation Prefix
- @DOX-Combined-DiskAssignmentStatus

## 3. Documentation Plane
Documentation under docs/ is authoritative.
Documentation defines conceptual architecture, requirements, implementation behavior, atoms, actions, and regeneration rules.
Documentation must not be regenerated automatically.
Documentation must not be rewritten to match code.
Documentation may be edited only by the DOX agent with explicit approval.
Code must follow documentation.

Authoritative Files
- docs/Architecture.md
- docs/Requirements.md
- docs/Implementation.md
- README.md
- docs/ATOMS.md
- docs/ACTIONS.md
- docs/REGENERATION.md

## 4. Source of Truth
Documentation is authoritative.
Code must conform to documentation.
Module paths must match documented architecture.
Documentation must be updated before implementation changes.
Documentation edits require DOX agent.

## 5. Module Architecture
Modules are located under Source/Modules/.

Architecture Layers
- Discovery: data collection only
- Evaluation: rule-based analysis only
- Reporting: user-facing output only
- Pipeline: deterministic JSON state emission

Rules
- No layer may contain responsibilities of another layer.
- Module names and paths must match documentation.

## 6. Module Bindings
Discovery
- Source/Modules/Discovery/* → Requirements.md (discovery rules)
Discovery produces no user-facing output; only logs, trace, and structured discovery objects are permitted.

Evaluation
- Source/Modules/Evaluation/* → Requirements.md (evaluation rules)

Reporting
- Source/Modules/Reporting/* → Implementation.md (user-facing output)

Pipeline
- Source/Modules/JSONState.psm1 → Architecture.md (JSON state emission)

Shared
- Source/Modules/Shared/* → Architecture.md

Validation
- Source/Modules/Validation/* → ACTIONS.md

Audit
- Source/Modules/Audit/* → REGENERATION.md

## 7. Documentation Bindings
Architecture.md → conceptual architecture and solution model
Requirements.md → evaluation rules and constraints
Implementation.md → script behavior and module structure
README.md → repository overview
ATOMS.md → atomic responsibilities
ACTIONS.md → actions and validation rules
REGENERATION.md → regeneration pipeline

## 8. Agent Responsibilities
Documentation alignment
Module regeneration
Validation
Audit
Workspace consistency
Drift detection
Script constraint enforcement
Module constraint enforcement
Regeneration planning

## 9. Agent Guarantees
Documentation is authoritative
Code follows documentation
Regeneration is patch-based
No automatic changes
No wrapper logic
No fallback logic
No ambiguous formatting
No environment-dependent branching
No undocumented behavior
No drift
No invented behavior

## 10. Agent Limitations
Does not infer undocumented modules
Does not extract atoms automatically
Does not modify files outside scope
Does not rewrite documentation except via DOX
Does not invent behavior
Does not normalize documentation lists

## 11. Regeneration Behavior
Regeneration is patch-based.

May propose
- create missing directories
- create missing module stubs
- update module headers
- align script headers with documentation
- align parameter blocks with documentation
- align logging and trace behavior with documentation

Must not
- apply changes automatically
- modify documentation
- invent behavior
- guess missing documentation

## 12. Audit Behavior
Audit logs stored under docs/agent-runs.

Audit logs include
- timestamp
- assumptions
- regeneration plan
- dryRun status
- consistency evaluation

Audit must not modify documentation.

## 13. Workspace Rules
Documentation-driven development enforced.
Code must follow documentation.
Documentation authoritative across layers.
Documentation edits require DOX agent.
Workspace rules override local rules unless explicitly overridden.
Workspace-Rules.md is authoritative for common repository structure.
Workspace-Rules.md defines DOX agent actions, responsibilities, and validation scope.
AGENTS.md references Workspace-Rules.md for workspace-level operational workflow.

## 14. Script Constraints
DiskAssignmentStatus.ps1 must contain a parameter block.
Script header must follow parameter block immediately.
Parameters Json, Verbose, t, l must follow documentation.
Script must implement deterministic orchestration only.
Script must not contain business logic; all business logic belongs in Discovery, Evaluation, Reporting, or Pipeline modules.

## 15. Implementation Constraints
No backticks.
Discovery produces no user-facing output.
Evaluation contains pure functions.
Reporting contains user-facing output only.
Pipeline emits deterministic JSON state only.
Behavior is deterministic.
Pipeline variables must be assigned before use.

## 16. Operational Workflow
Agents operate in the documentation plane.
VS Code and Claude Code operate in the workspace plane.
Human approval is required for all changes.
Agents produce FLAT blocks.
FLAT blocks contain deterministic actionable steps.
FLAT blocks are passed to VS Code or Claude Code.
No agent action is executed automatically.
Human approval is mandatory before execution.

## 17. DocContext.json Binding
DocContext.json defines
- documentation paths
- module paths
- validation targets
- audit targets
- regeneration targets

DocContext.json is authoritative for regeneration planning.

## 18. Common structure in repositories of the workspace
See .github/agents/Workspace-Rules.md for authoritative workspace repository structure.

## 19. Commands

scaffold
@DOX-Combined-DiskAssignmentStatus scaffold
Creates missing directories and module stubs according to documentation and DocContext.json.

validate
@DOX-Combined-DiskAssignmentStatus validate
Checks consistency between documentation, module structure, and implementation.

regenerate
@DOX-Combined-DiskAssignmentStatus regenerate
Proposes patches to align implementation with documentation.

audit
@DOX-Combined-DiskAssignmentStatus audit
Produces a full audit log of the current workspace state.

## 20. Version
Current version: 2.1.0
Future changes must increment version and document the change.

