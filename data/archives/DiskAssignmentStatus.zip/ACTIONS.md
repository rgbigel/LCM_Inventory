﻿# ACTIONS — Version 2.0.0

## 1. Purpose
Define deterministic migration, validation, regeneration, and JSON-state actions for the DiskAssignmentStatus repository using authoritative documentation, SharedModules integration, cross-repository recovery evaluation atoms, and workspace rule agents.

## 2. Agents
D:\Git_Repositories\.github\agents\MIGRATION-Rules.md
D:\Git_Repositories\.github\agents\SharedModulesRule.md
D:\Git_Repositories\.github\agents\ATOM-Building.md
D:\Git_Repositories\.github\agents\DOX.agent.md
D:\Git_Repositories\DiskAssignmentStatus\DiskAssignment.AGENTS.md

## 3. Documentation Plane
D:\Git_Repositories\DiskAssignmentStatus\docs\Architecture.md
D:\Git_Repositories\DiskAssignmentStatus\docs\Requirements.md
D:\Git_Repositories\DiskAssignmentStatus\docs\Implementation.md
D:\Git_Repositories\DiskAssignmentStatus\README.md

Note: `README.md` at the repository root is the authoritative README file. A `docs/README.md` file does not exist.

## 4. Context
D:\Git_Repositories\DiskAssignmentStatus\DocContext.json

## 5. Module Structure
D:\Git_Repositories\DiskAssignmentStatus\Modules\Discovery
D:\Git_Repositories\DiskAssignmentStatus\Modules\Evaluation
D:\Git_Repositories\DiskAssignmentStatus\Modules\Reporting
D:\Git_Repositories\DiskAssignmentStatus\Modules\RecoveryEvaluation
D:\Git_Repositories\DiskAssignmentStatus\Modules\JSONState

## 6. Migration Actions
1. Load rule agents.
2. Load DiskAssignment.AGENTS.md.
3. Validate documentation plane.
4. Validate module structure.
5. Detect missing directories.
6. Detect missing pure\ module\ stubs\ \(\*\.ps1m\).
7. Detect header misalignment.
8. Detect parameter block misalignment.
9. Detect logging and trace misalignment.
10. Detect SharedModules\ \(runtime-plane\) logging and path integration drift.
11. Detect documentation inconsistencies.
12. Detect documentation vs implementation output mode drift.
13. Detect missing recovery evaluation atoms (WinRE, recovery partition, layout status, required fix, recommended action).
14. Detect missing JSON-state atoms (model construction, normalization, schema validation, serialization, version stamping, merge, emission).
15. Produce regeneration plan.

## 7. Validation Actions
1. Validate architecture.
2. Validate requirements.
3. Validate implementation.
4. Validate script header.
5. Validate parameter block.
6. Validate deterministic orchestration.
7. Validate module purity.
8. Validate reporting behavior.
9. Validate pipeline variable usage.
10. Validate constraints.
11. Validate documented parameter contract vs actual supported parameters.
12. Validate SharedModules\ \(runtime-plane\) logging and private path usage.
13. Validate recovery evaluation output fields.
14. Validate JSON-state model, normalization, schema, serialization, and emission boundaries.

## 8. Regeneration Actions
1. Propose directory creation.
2. Propose module stub creation.
3. Propose header alignment.
4. Propose parameter alignment.
5. Propose logging alignment.
6. Propose trace alignment.
7. Propose documentation alignment.
8. Propose consistency fixes.
9. Propose recovery evaluation implementation alignment.
10. Propose JSON-state pipeline implementation alignment.
11. Produce patch proposals.

## 9. Audit Actions
1. Create audit log directory.
2. Record timestamp.
3. Record assumptions.
4. Record regeneration plan.
5. Record dryRun status.
6. Record consistency evaluation.
7. Record recovery evaluation alignment status.
8. Record JSON-state pipeline alignment status.

## 10. Commands
scaffold
validate
regenerate
audit

## 11. Completion Criteria
Migration complete when:
- documentation plane validated
- module structure validated
- SharedModules\ \(runtime-plane\) integration validated
- recovery evaluation atoms validated
- JSON-state pipeline validated
- inconsistencies detected
- output mode drift assessed
- regeneration plan produced
- audit log generated

Action:
  Id: RefreshCycle.DiskAssignmentStatus.v2.0.0
  Scope: DiskAssignmentStatus
  Description: Run a refreshment cycle using Methodology v2.0.0 and update documentation accordingly.
  Steps:
    - Step: Discovery
      Task: Re-scan DiskAssignmentStatus repo structure, modules, and docs for current state.
    - Step: Evaluation
      Task: Identify drift, inconsistencies, and missing links in docs and module responsibilities.
    - Step: Reporting
      Task: Write findings into D:\Git_Repositories\DiskAssignmentStatus\logs\agent-runs\DiskAssignmentStatus.StabilizationLog.md (append to existing content).
    - Step: ACTIONS
      Task: Propose concrete documentation edits and SharedModules promotion candidates, but do not modify other repos.
    - Step: Pipeline
      Task: Apply accepted documentation edits within DiskAssignmentStatus only; write cross-repo ideas to D:\Git_Repositories\DiskAssignmentStatus\docs\CrossRepo.proposals.md.
  Constraints:
    - Do not touch other repositories.
    - Do not change SharedModules; only propose.
    - Keep all changes deterministic and documented.

Action:
  Id: DiskAssignmentStatus.Scaffold
  Do:
    - Create D:\Git_Repositories\DiskAssignmentStatus\docs\CrossRepo.proposals.md if missing.
    - Append "Scaffold Findings" to D:\Git_Repositories\DiskAssignmentStatus\logs\agent-runs\DiskAssignmentStatus.StabilizationLog.md.
    - Insert required missing sections into D:\Git_Repositories\DiskAssignmentStatus\logs\agent-runs\DiskAssignmentStatus.StabilizationLog.md.
    - Ensure all required documentation files exist inside DiskAssignmentStatus.
    - Update any incomplete sections in DiskAssignmentStatus docs.
    - Record cross-repo implications in D:\Git_Repositories\DiskAssignmentStatus\docs\CrossRepo.proposals.md.
  Constraints:
    - Only modify DiskAssignmentStatus.
    - Respect SharedModulesRule and ATOM-Building.md.

Action:
  Id: DiskAssignmentStatus.Validate
  Scope: DiskAssignmentStatus
  Description: Validate DiskAssignmentStatus against Methodology v2.0.0, SharedModulesRule, and ATOM-Building.md.
  Steps:
    - Step: Discovery
      Task: Scan modules, scripts, and docs for compliance-related signals (structure, naming, responsibilities).
    - Step: Evaluation
      Task: Check alignment with Methodology v2.0.0 (Discovery → Evaluation → Reporting → ACTIONS → Pipeline) and GenericLayerModel-proposal.md where applicable.
    - Step: Reporting
      Task: Append a "Validation Results" section to D:\Git_Repositories\DiskAssignmentStatus\logs\agent-runs\DiskAssignmentStatus.StabilizationLog.md with findings and classification (OK / Drift / Missing).
    - Step: ACTIONS
      Task: Propose specific corrections (docs, comments, structure) for DiskAssignmentStatus only.
    - Step: Pipeline
      Task: Apply accepted corrections locally; write any SharedModules or cross-repo implications to D:\Git_Repositories\DiskAssignmentStatus\docs\CrossRepo.proposals.md.
  Constraints:
    - No direct edits to SharedModules.
    - No changes to other repositories.
    - All validation outcomes must be recorded.

Action:
  Id: DiskAssignmentStatus.Regenerate
  Scope: DiskAssignmentStatus
  Description: Regenerate documentation and supporting structures based on current code and Methodology v2.0.0.
  Steps:
    - Step: Discovery
      Task: Re-scan source code, modules, and existing docs for current behavior and responsibilities.
    - Step: Evaluation
      Task: Identify outdated, inconsistent, or incomplete documentation and structural descriptions.
    - Step: Reporting
      Task: Write regeneration proposals into D:\Git_Repositories\DiskAssignmentStatus\logs\agent-runs\DiskAssignmentStatus.StabilizationLog.md under "Regeneration Proposals".
    - Step: ACTIONS
      Task: Define exact doc edits, section rewrites, and structural description updates for DiskAssignmentStatus.
    - Step: Pipeline
      Task: Apply accepted regeneration edits; log any SharedModules promotion candidates or cross-repo effects in D:\Git_Repositories\DiskAssignmentStatus\docs\CrossRepo.proposals.md.
  Constraints:
    - Respect SharedModulesRule and ATOM-Building.md.
    - Do not regenerate other repositories.
    - Keep all changes deterministic and traceable.

Action:
  Id: DiskAssignmentStatus.Audit
  Scope: DiskAssignmentStatus
  Description: Audit DiskAssignmentStatus for drift, duplication, and SharedModules promotion opportunities.
  Steps:
    - Step: Discovery
      Task: Identify duplicated patterns, cross-cutting concerns, and potential atoms within DiskAssignmentStatus.
    - Step: Evaluation
      Task: Classify findings according to ATOM-Building.md (atoms, candidates, non-atoms) and SharedModulesRule.
    - Step: Reporting
      Task: Append an "Audit Results" section to D:\Git_Repositories\DiskAssignmentStatus\logs\agent-runs\DiskAssignmentStatus.StabilizationLog.md summarizing drift, duplication, and atom candidates.
    - Step: ACTIONS
      Task: Propose local cleanup actions and SharedModules promotion candidates.
    - Step: Pipeline
      Task: Apply accepted local cleanup; record SharedModules promotion proposals and cross-repo impacts in D:\Git_Repositories\DiskAssignmentStatus\docs\CrossRepo.proposals.md.
  Constraints:
    - No direct SharedModules modifications.
    - No changes to other repositories.
    - All audit findings must be documented before any edits.
