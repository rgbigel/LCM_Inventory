# DiskAssignmentStatus Installation Guide

## Prerequisites
- PowerShell 7 (`pwsh`) is required because the script self-elevates under PowerShell 7 when needed.
- Administrator rights are required for the main runtime flow and system inventory operations.
- ExecutionPolicy is handled by the script relaunch via `-ExecutionPolicy Bypass`; no permanent policy change is required.
- Windows 10 and Windows 11 are supported for the disk, partition, and recovery discovery operations used by the script.

## Installation Layout
- The primary script is located in `Source\DiskAssignmentStatus.ps1` in the repository.
- Helper modules are resolved via `PrivatePaths.psm1` and `Logging.psm1`.
- The script searches `PrivatePaths.psm1` in this order:
  1. `D:\Git_Repositories\DiskAssignmentStatus\Modules\PrivatePaths.psm1`
  2. `D:\Git_Repositories\SharedModules\Modules\PrivatePaths.psm1`
- Logging modules are searched in this order:
  1. `D:\Git_Repositories\DiskAssignmentStatus\Modules\Logging.psm1`
  2. `D:\Git_Repositories\SharedModules\Modules\Logging.psm1`
  3. `D:\Git_Repositories\BackgroundModifier\Modules\Logging.psm1`
  4. `C:\BootOpsHub\SolutionCode\Modules\Logging.psm1`
- These module paths are hard-coded in the script. If the modules are moved or renamed, update the script paths accordingly.

## Elevation Behavior
- The script detects administrator rights by checking the current Windows principal role.
- If the user is not elevated, the script builds a preserved relaunch argument list using `Get-RelaunchArgumentList`.
- The script relaunches itself with `Start-Process -FilePath "pwsh.exe" -Verb RunAs`.
- The relaunch helper preserves all bound parameters and any unbound arguments, so the elevated process receives the same invocation semantics.

## Logging Setup
- `-LogMode` enables file logging.
- `-TraceMode` enables trace output and also causes trace lines to be logged when logging is enabled.
- `-LogFile` specifies an explicit log file path; providing this value automatically enables logging.
- When `-LogFile` is omitted, the script generates a timestamped log file in the configured temporary root.
- The log file name format is `DiskAssignmentStatus_<yyyyMMdd_HHmmss>.log`.
- Logs are stored in the configured `$TempRoot` path or the explicit `-LogFile` location.
- To disable logging, omit both `-LogMode` and `-LogFile` and do not use `-TraceMode`.

## Usage
### Run normally
```powershell
.\Source\DiskAssignmentStatus.ps1
```

### Show MSR partitions
```powershell
.\Source\DiskAssignmentStatus.ps1 -ShowMSR
```

### Run with file logging
```powershell
.\Source\DiskAssignmentStatus.ps1 -LogMode
```

### Run with tracing enabled
```powershell
.\Source\DiskAssignmentStatus.ps1 -TraceMode
```

### Specify an explicit log file
```powershell
.\Source\DiskAssignmentStatus.ps1 -LogFile "C:\Temp\DiskAssignmentStatus.log"
```

## Output
- The script renders a fixed-width table of disk, partition, and volume information.
- The table includes centered columns for disk number, partition number, and drive letter.
- The output includes `PartitionStyle` values such as `GPT`, `MBR`, or `RAM` for ramdisk-resolved partitions.
- Attribute flags are shown in the `Attrs` column: `S` for system and `H` for hidden partitions.
- The fixed-width layout is stabilized with a wide buffer and `Format-Table` autosize disabled.

## Optional Integration
- You can add a launcher script or shortcut to your preferred tools folder that invokes `Source\DiskAssignmentStatus.ps1`.
- You can add a Start Menu or Taskbar shortcut to the PowerShell launcher with the same target to provide quick access to the tool.

## Troubleshooting
- **Missing modules**: Ensure `PrivatePaths.psm1` and `Logging.psm1` exist in the expected repository or shared module paths, because the script relies on these explicit locations.
- **Non-elevated execution**: If the script reports it is not elevated, allow the `RunAs` relaunch or run `pwsh` as administrator directly.
- **No disks returned**: Verify `Get-Disk`, `Get-Partition`, and `Get-Volume` work in the current PowerShell 7 environment.
- **Recovery partition not detected**: Recovery discovery may be limited by `reagentc` output or the BCD state on the machine; ensure WinRE is installed and accessible.

## Non-Goals
- This script does not modify disks or partitions.
- This script does not repair Windows Recovery Environment configuration.
- This script does not change BCD settings.
- It does not mount or unmount partitions.

