﻿# DiskAssignmentStatus â€” Implementation (Version 2.0.0)

This document describes the technical implementation of DiskAssignmentStatus. It explains how modules, atoms, and SharedModules\ \(runtime-plane\) integrate to produce deterministic diagnostics for Windows storage systems.

## 1. Implementation Model

DiskAssignmentStatus is implemented as a deterministic pipeline:
- Discovery
- Evaluation
- RecoveryEvaluation
- JSONState
- Reporting

All logic resides in modules and atoms. The main script contains no business logic.

## 2. SharedModules\ \(runtime-plane\) Integration

SharedModules\ \(runtime-plane\) provides all cross-cutting functionality:
- LoggingContext
- TraceContext
- PrivatePaths
- Version metadata

SharedModules\ \(runtime-plane\) modules used:
- SharedSource/Modules/Source/Modules/PrivatePaths.psm1
- SharedSource/Modules/Source/Modules/Logging.psm1
- SharedSource/Modules/Source/Modules/Trace.psm1

Local overrides, fallback search paths, and legacy wrappers are removed.

## 3. Module Structure

Modules are located under:
- Source/Modules/Discovery
- Source/Modules/Evaluation
- Source/Modules/Reporting

Each module contains deterministic atoms. Atoms do not perform side effects except Reporting atoms.

Modules used:
- Discovery.psm1
- Evaluation.psm1
- RecoveryEvaluation.psm1
- JSONState.psm1
- Reporting.psm1

## 4. Atom Responsibilities

Discovery atoms:
- Collect raw disk, partition, volume, RE, and BCD data
- Return structured objects
- Perform no logging or trace

Evaluation atoms:
- Classify partitions
- Interpret GPT and MBR metadata
- Detect alignment
- Detect gaps
- Assign partition numbers
- Evaluate recovery partition presence
- Evaluate WinRE configuration
- Determine corrective action
- Perform no logging or trace

RecoveryEvaluation atoms:
- Interpret reagentc.exe /info
- Interpret bcdedit /enum all /v
- Map volumes to partitions
- Infer recovery partitions
- Perform no logging or trace

JSONState atoms:
- Produce deterministic JSON output
- Include all evaluation fields
- Include recovery inference results
- Perform no logging or trace

Reporting atoms:
- Render fixed-width table
- Use SharedModules\ \(runtime-plane\) LoggingContext
- Use SharedModules\ \(runtime-plane\) TraceContext
- Produce structured log entries
- Produce trace output
- Perform all side effects

## 5. Source-layer\ orchestration

The main script (Source/DiskAssignmentStatus.ps1) performs:
- Elevation check
- SharedModules\ \(runtime-plane\) loading
- Pipeline orchestration
- Logging and trace activation
- Output rendering

The script must contain:
- A parameter block defining all supported parameters
- A script header containing Module, Purpose, Path, Authors, Version, and Changelog
- The script header must appear immediately after the parameter block

The script does not contain logic for:
- partition classification
- recovery inference
- JSON generation
- table formatting

All such logic resides in modules.

## 6. Deterministic Behavior

All modules and atoms must be deterministic:
- No fallback logic
- No local wrappers
- No optional modes
- No environment-dependent branching

The same inputs must always produce the same outputs.

## 7. Recovery Detection Implementation

Recovery detection is implemented entirely in RecoveryEvaluation atoms:
- reagentc.exe /info parsing
- BCD enumeration parsing
- device-to-partition mapping
- recovery inference

The main script does not perform recovery probing.

## 8. Logging and Trace Implementation

Logging and trace use SharedModules\ \(runtime-plane\):
- LoggingContext
- TraceContext

Logging must:
- respect the -l flag
- be automatically enabled when -t is specified
- produce structured log entries

Trace must:
- record discovery steps
- record evaluation steps
- record recovery inference steps

Removed behaviors:
- Write-RunLog
- Write-TraceLog
- Out-File fallback writer
- local logging modules

## 9. Output Implementation

Reporting atoms produce:
- fixed-width table
- aligned columns
- sorted rows

JSONState atoms produce:
- deterministic JSON output
- complete evaluation fields
- recovery inference fields

## 10. Coding Requirements

Coding rules:
- No backticks
- Pipeline variables must assign $_ to a named variable before use
- All functions must be deterministic
- No hidden side effects

## 11. Non-Goals

Implementation does not include:
- disk modification
- partition repair
- Windows RE repair
- partition style changes
- volume mount or unmount
- recovery actions

## Additional Structural References
- Install/: installation and deployment rules
- Source/: orchestrator scripts
- Source/Modules/: combined execution layer
- Modules/*.ps1m: pure technical modules
- logs/agent-runs/: audit logs

