# MODULES — Version 2.2.0

## Module: Modules/Discovery
Responsibility: Deterministic discovery of disks, partitions, volumes, filesystem metadata, and WinRE/recovery configuration.
Inputs: Raw system disk state, partition tables, volume metadata, WinRE registry and reagentc state.
Outputs: Structured discovery object containing disks, partitions, volumes, filesystem metadata, and WinRE mapping.
Boundaries: Pure discovery; no evaluation, no reporting, no JSON emission, no SharedModules inference.
Reason: Discovery is a pipeline-level module required by multiple repos and must remain deterministic and side-effect free.

## Module: Modules/Evaluation
Responsibility: Deterministic evaluation of disk alignment, recovery status, partition layout correctness, and required corrective actions.
Inputs: Discovery output, alignment classification atoms, recovery inference atoms, partition layout atoms.
Outputs: Structured evaluation object containing alignment status, recovery status, layout status, required fixes, and recommended actions.
Boundaries: Pure evaluation; no discovery, no reporting, no JSON emission.
Reason: Evaluation is a pipeline-level module shared across repos and must remain strictly deterministic.

## Module: Modules/Reporting
Responsibility: Produce deterministic fixed-width reporting output summarizing discovery and evaluation results.
Inputs: Discovery output, Evaluation output, SharedModules LoggingContext.
Outputs: Fixed-width table output, trace/log entries, and SharedModules-consistent logging artifacts.
Boundaries: Reporting only; no discovery, no evaluation, no JSON emission.
Reason: Reporting is a pipeline-level module required by multiple repos and must remain stable and predictable.

## Module: Modules/RecoveryEvaluation
Responsibility: Evaluate WinRE validity, recovery partition presence, partition layout correctness, required fixes, and recommended actions.
Inputs: Discovery output, recovery inference atoms, partition layout atoms.
Outputs: Recovery evaluation object containing WinRE validity, recovery partition status, layout status, required fixes, and recommended actions.
Boundaries: Evaluation sub-module; no reporting, no JSON emission.
Reason: Recovery evaluation is a pipeline-level evaluation sub-module shared across repos and must remain deterministic.

## Module: Modules/JSONState
Responsibility: Construct, normalize, validate, serialize, stamp, merge, and emit deterministic JSON state for disk and recovery evaluation across repositories.
Inputs: Discovery output, Evaluation output, RecoveryEvaluation output, SharedModules PrivatePaths, SharedModules version metadata, SharedModules LoggingContext.
Outputs: Deterministic state model, validated JSON string, version-stamped JSON file for cross-repo consumption.
Boundaries: Pipeline-level module; candidate for SharedModules promotion once schema and merge semantics stabilize.
Reason: JSON-state persistence is a cross-repository requirement and relies on SharedModules atoms; it defines long-term disk state memory consumed by multiple repos and therefore cannot be classified as repo-specific.
