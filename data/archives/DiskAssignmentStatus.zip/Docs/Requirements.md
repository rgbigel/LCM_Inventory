﻿# DiskAssignmentStatus â€” Requirements (Version 2.0.0)

This document defines the functional, architectural, behavioral, and documentation requirements for DiskAssignmentStatus. These requirements are authoritative. Source code must conform to this document.

## 1. Purpose

DiskAssignmentStatus evaluates Windows disk, partition, and recovery configuration and reports a deterministic status describing whether the system meets documented requirements. Requirements define expected behavior, evaluation rules, and implementation constraints.

Documentation is the authoritative source of truth. Code must follow documentation.

## 2. Functional Requirements

### 2.1 Discovery Requirements

The tool must collect raw system facts including:
- Physical disks
- Partition table type (GPT or MBR)
- Partition entries
- Partition GUID types
- Partition sizes and offsets
- Volumes
- Volume GUIDs
- Mount points
- File system type
- BitLocker status when available
- Windows RE configuration
- WinRE enabled state
- WinRE location
- WinRE validity
- BCD entries related to recovery
- Partition-to-volume mappings

Discovery must return structured objects only. Discovery must not evaluate or report.

### 2.2 Evaluation Requirements

Evaluation must apply documented rules to discovery data and produce a structured evaluation object containing:
- HasValidWinRE
- HasRecoveryPartition
- PartitionLayoutStatus
- RequiresFix
- RecommendedAction

Evaluation must determine:
- Whether a valid recovery partition exists
- Whether WinRE is present and correctly configured
- Whether the partition layout meets documented requirements
- Whether corrective action is required
- What corrective action is recommended

Evaluation must be pure and deterministic. Evaluation must not perform discovery or reporting.

### 2.3 Reporting Requirements

Reporting must convert evaluation results into operator-facing output formats:
- Human-readable console output
- JSON output
- Structured log entries

Reporting must not modify evaluation objects. Reporting must not perform discovery or evaluation.

## 3. Behavioral Requirements

### 3.1 Parameter Behavior

The tool must support:
- -Json
- -Verbose
- -t
- -l
- -ShowMSR

### 3.2 Parameter Interactions

Behavioral rule:
- The -t flag automatically enables -l

### 3.3 Output Behavior

Output must be deterministic:
- Console output must be structured and human-readable
- JSON output must reflect the evaluation object
- Logging must produce structured entries

### 3.4 Error Behavior

Errors must be deterministic:
- Fail gracefully when discovery cannot complete
- Emit meaningful error messages
- Exit with deterministic status codes

## 4. Architectural Requirements

### 4.1 Layer Separation

Architecture must preserve strict separation:
- Discovery must not evaluate or report
- Evaluation must not discover or report
- Reporting must not discover or evaluate
- The main script must remain a thin orchestrator

### 4.2 Module Structure

Modules must be located under:
- Source/Modules/Discovery
- Source/Modules/Evaluation
- Source/Modules/Reporting

Each module must implement only the responsibilities of its layer.

### 4.3 SharedModules Requirements

SharedModules must provide:
- LoggingContext
- TraceContext
- PrivatePaths
- Version metadata

Local logging modules, fallback writers, and legacy wrappers must not be used.

### 4.4 Script Header Requirements

The main script must contain a script header with:
- Module
- Purpose
- Path
- Authors
- Version
- Changelog

The script header must appear immediately after the parameter block.

### 4.5 Parameter Block Requirements

The main script must contain a parameter block defining all supported parameters.

## 5. Implementation Requirements

### 5.1 Deterministic Behavior

All functions must behave deterministically. No hidden side effects are permitted.

### 5.2 No Backticks

Backticks must not be used anywhere in the implementation.

### 5.3 Pipeline Variable Assignment

When using pipeline variables, $_ must be assigned to a named variable before use.

### 5.4 Logging Requirements

Logging must:
- Use SharedModules LoggingContext
- Respect the -l flag
- Be automatically enabled when -t is specified
- Produce structured log entries

### 5.5 Trace Requirements

Trace must:
- Use SharedModules TraceContext
- Record discovery steps
- Record evaluation steps
- Record recovery inference steps

### 5.6 Elevation Requirements

If elevation is required for discovery operations, this requirement must be documented and implemented deterministically.

## 6. Evaluation Rules

Evaluation rules must be documented and implemented as pure functions. Rules include:
- Recovery partition presence and validity
- WinRE presence and configuration
- Partition layout compliance
- Determination of required corrective action

Evaluation rules must be documented in this file and in docs/Implementation.md.

## 7. Documentation Requirements

The following documentation files are authoritative:
- docs/Architecture.md
- docs/Requirements.md
- docs/README.md
- docs/Implementation.md

Documentation must be updated before implementation changes are made. Code must follow documentation.

