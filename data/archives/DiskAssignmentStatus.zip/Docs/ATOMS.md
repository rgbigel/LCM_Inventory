# ATOMS — Version 2.0.0

Name: DISCOVERY.SystemDiskDiscovery.CollectDiskState
Category: DISCOVERY
Group: SystemDiskDiscovery
Action: CollectDiskState
Description: Collects disks, partitions, volumes, and WinRE/recovery mapping data.
Source: DiskAssignmentStatus

Name: EVALUATION.PartitionAlignmentClassification.ClassifyAlignment
Category: EVALUATION
Group: PartitionAlignmentClassification
Action: ClassifyAlignment
Description: Determines alignment status of partitions and identifies misalignment conditions.
Source: DiskAssignmentStatus

Name: EVALUATION.RecoveryStatusInference.InferRecoveryStatus
Category: EVALUATION
Group: RecoveryStatusInference
Action: InferRecoveryStatus
Description: Infers recovery partition validity, WinRE presence, and recovery volume correctness.
Source: DiskAssignmentStatus

Name: REPORTING.FixedWidthTableRendering.RenderTable
Category: REPORTING
Group: FixedWidthTableRendering
Action: RenderTable
Description: Renders a fixed-width table summarizing discovery and evaluation results.
Source: DiskAssignmentStatus

Name: EVALUATION.RecoveryEvaluation.HasValidWinRE
Category: EVALUATION
Group: RecoveryEvaluation
Action: HasValidWinRE
Description: Determines whether the WinRE environment is valid and correctly mapped.
Source: Get-RecoveryVolume

Name: EVALUATION.RecoveryEvaluation.HasRecoveryPartition
Category: EVALUATION
Group: RecoveryEvaluation
Action: HasRecoveryPartition
Description: Determines whether a valid recovery partition exists and is correctly configured.
Source: Get-RecoveryVolume

Name: EVALUATION.RecoveryEvaluation.PartitionLayoutStatus
Category: EVALUATION
Group: RecoveryEvaluation
Action: PartitionLayoutStatus
Description: Evaluates the partition layout for correctness, ordering, and required adjustments.
Source: Get-RecoveryVolume

Name: EVALUATION.RecoveryEvaluation.RequiresFix
Category: EVALUATION
Group: RecoveryEvaluation
Action: RequiresFix
Description: Determines whether recovery or partition layout issues require corrective action.
Source: Get-RecoveryVolume

Name: EVALUATION.RecoveryEvaluation.RecommendedAction
Category: EVALUATION
Group: RecoveryEvaluation
Action: RecommendedAction
Description: Produces a deterministic recommended action based on recovery and layout evaluation.
Source: Get-RecoveryVolume

Name: JSON.StateModelConstruction.BuildStateModel
Category: JSON
Group: StateModelConstruction
Action: BuildStateModel
Description: Constructs a deterministic combined disk and recovery evaluation state model.
Source: DiskAssignmentStatus

Name: JSON.StateNormalization.NormalizeStateModel
Category: JSON
Group: StateNormalization
Action: NormalizeStateModel
Description: Normalizes the state model into canonical ordering and stable structure.
Source: DiskAssignmentStatus

Name: JSON.StateSchemaValidation.ValidateStateSchema
Category: JSON
Group: StateSchemaValidation
Action: ValidateStateSchema
Description: Validates the normalized state model against a deterministic schema.
Source: DiskAssignmentStatus

Name: JSON.StateSerializationToJson.SerializeToJson
Category: JSON
Group: StateSerializationToJson
Action: SerializeToJson
Description: Serializes the validated state model into deterministic JSON.
Source: DiskAssignmentStatus

Name: JSON.StateJsonFileEmission.EmitJsonFile
Category: JSON
Group: StateJsonFileEmission
Action: EmitJsonFile
Description: Writes the JSON string to a file path resolved by SharedModules PrivatePaths.
Source: DiskAssignmentStatus

Name: JSON.StateVersionStamping.StampVersionMetadata
Category: JSON
Group: StateVersionStamping
Action: StampVersionMetadata
Description: Embeds version metadata into the state model before serialization.
Source: DiskAssignmentStatus

Name: JSON.StateMergeWithRecoveryInference.MergeRecoveryInference
Category: JSON
Group: StateMergeWithRecoveryInference
Action: MergeRecoveryInference
Description: Merges DiskAssignmentStatus evaluation with recovery inference results.
Source: DiskAssignmentStatus
