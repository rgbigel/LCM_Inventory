# CrossLayerFlowDiagram.md — Version 3.2.0
# DiskAssignmentStatus — Cross-Layer Governance Flow (Conceptual)
# ascii-only, deterministic-structure, documentation-plane

## 1. PURPOSE
Visualize the governance flow across workspace rules, agents, documentation, repository, modules, architecture, implementation, regeneration, confirmation logs, and organization layers.
Human-oriented conceptual model; not machine-executable.

# Layer: Workspace Rules
  Where: D:\Git_Repositories\.copilot\Workspace-Rules.md
    ↓ defines global constraints
    ↓ defines documentation immutability
    ↓ defines regeneration boundaries
    ↓ defines forbidden paths
    ↓ defines DOX editing exception
    ↓ overrides repo-local rules

# Layer: Workspace Agents
  Where: D:\Git_Repositories\.copilot\agent.json
    ↓ enforce workspace rules
    ↓ enforce deterministic behavior
    ↓ enforce documentation immutability
    ↓ provide DOX editing capability (with explicit approval)
    ↑ inherit workspace constraints

# Layer: Repository
  Where: DiskAssignmentStatus\ACTIONS.md
  Where: DiskAssignmentStatus\AGENTS.md
  Where: DiskAssignmentStatus\README.md
    ↓ defines repo-level behavior
    ↓ defines repo-level constraints
    ↓ defines repo-level documentation rules

# Layer: Repository Rules
  Where: DiskAssignmentStatus\Methods\DiskAssignmentStatus.AGENTS.md
    ↓ bind repo to workspace agents
    ↓ enforce documentation-driven development
    ↓ enforce regeneration safety
    ↓ enforce architecture constraints
    ↑ inherit workspace rules

# Layer: Repository Agents
  Where: DiskAssignmentStatus\Agents\
    ↓ enforce documentation-plane authority
    ↓ enforce module-boundary rules
    ↓ enforce regeneration constraints
    ↓ enforce evaluation/reporting rules
    ↑ inherit workspace-agent rules

# Layer: Documentation Plane
  Where: DiskAssignmentStatus\Docs\
    ↑ defines architecture
    ↑ defines module responsibilities
    ↑ defines evaluation rules
    ↑ defines reporting rules
    ↑ defines script constraints
    ↑ defines regeneration boundaries
    ↑ defines audit requirements

  Where: DiskAssignmentStatus\Docs\DocContext.json
    ↑ declares documentation authoritative
    ↑ declares docs read-only except DOX edits
    ↑ declares regeneration limited to Source and Modules

  Where: DiskAssignmentStatus\Docs\Requirements.md
    ↓ defines rule logic
    ↓ defines partition logic
    ↓ defines WinRE logic
    ↓ defines MSR visibility rules
    ↓ defines gap detection rules

  Where: DiskAssignmentStatus\Docs\Implementation.md
    ↓ defines source- and module paths
    ↓ defines module interfaces and caller responsibilities
    ↓ defines script orchestration model

  Where: DiskAssignmentStatus\Docs\Architecture.md
    ↓ defines Discovery → Evaluation → JSONState → Recovery → Reporting

  Where: DiskAssignmentStatus\Docs\ATOMS.md
  Where: DiskAssignmentStatus\Docs\MODULES.md

# Layer: Installation
  Where: DiskAssignmentStatus\Install\Installation.md
    ↓ defines installation behavior
    ↓ defines deployment boundaries
    ↓ defines operator-facing setup rules

# Layer: Module Architecture
  Where: DiskAssignmentStatus\Modules\
    ↑ must match documentation
    ↑ must follow layer boundaries
    ↑ must implement only documented responsibilities

  Where: DiskAssignmentStatus\Modules\Discovery
  Where: DiskAssignmentStatus\Modules\Evaluation
  Where: DiskAssignmentStatus\Modules\JSONState
  Where: DiskAssignmentStatus\Modules\RecoveryEvaluation
  Where: DiskAssignmentStatus\Modules\Reporting

# Layer: Source
  Where: DiskAssignmentStatus\Source\
    ↓ contains orchestrator scripts
    ↓ contains module entry points
    ↓ contains deterministic execution logic
    ↑ must follow Implementation.md

  Where: DiskAssignmentStatus\Source\DiskAssignmentStatus.ps1

# Layer: Implementation
    ↓ orchestrates modules deterministically
    ↓ contains no business logic
    ↓ follows documented parameter behavior

# Layer: Regeneration
  Where: DiskAssignmentStatus\Methods\REGENERATION.md
    ↓ aligns implementation with documentation
    ↓ creates missing directories
    ↓ creates missing module stubs
    ↓ updates module headers
    ↓ aligns script headers
    ↓ aligns parameter blocks
    ↓ aligns logging and trace behavior
    ↓ never modifies documentation
    ↓ never invents behavior

  Where: DiskAssignmentStatus\Methods\ACTION_QUEUE.md
  Where: DiskAssignmentStatus\Methods\ATOMS.proposal.md
  Where: DiskAssignmentStatus\Methods\CODE_CHANGES.proposal.md
  Where: DiskAssignmentStatus\Methods\CrossRepo.proposals.md
  Where: DiskAssignmentStatus\Methods\DiskAssignmentStatus.StabilizationPlan.md
  Where: DiskAssignmentStatus\Methods\DOC_ALIGNMENT.proposal.md
  Where: DiskAssignmentStatus\Methods\DOX_EXECUTION_LOCK.md
  Where: DiskAssignmentStatus\Methods\MODULES.proposal.md
  Where: DiskAssignmentStatus\Methods\REGENERATION.proposal.md
  Where: DiskAssignmentStatus\Methods\RepoAgentIndex.md
  Where: DiskAssignmentStatus\Methods\TOOLS.md

# Layer: ConfirmationLogs
  Where: DiskAssignmentStatus\logs\
  Where: DiskAssignmentStatus\logs\agent-runs\
  Where: DiskAssignmentStatus\logs\FINAL_AUDIT.md
  Where: DiskAssignmentStatus\logs\NEXT_CYCLE.md
  Where: DiskAssignmentStatus\logs\REGENERATION.log.md
  Where: DiskAssignmentStatus\logs\STABILIZATION.md
  Where: DiskAssignmentStatus\logs\VALIDATION.md
  Where: DiskAssignmentStatus\logs\WORKSPACE-SYNC.md
  Where: DiskAssignmentStatus\logs\agent-runs\CLOSURE.md
  Where: DiskAssignmentStatus\logs\agent-runs\DiskAssignmentStatus-agent-run-log.json

# Layer: Organization
  Where: DiskAssignmentStatus\Organization\
    ↓ cross-reference requirements
    ↓ reverse-index implementation locations
    ↓ provide structural mapping across layers

# ASCII DIAGRAM (Conceptual, Bidirectional)

                Workspace Rules
                        ↓
                Workspace Agents
                        ↓
                    Repository
                        ↓
                Repository Rules
                        ↓
                Repository Agents
                        ↓
                Documentation Plane
                        ↓
                  Installation
                        ↓
                Module Architecture
                        ↓
                    Source
                        ↓
                Implementation
                        ↓
                 Regeneration
                        ↓
               ConfirmationLogs
                        ↓
                 Organization

STATUS: active
