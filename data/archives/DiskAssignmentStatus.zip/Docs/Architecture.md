﻿# DiskAssignmentStatus — Architecture (Version 2.0.0)

DiskAssignmentStatus is a deterministic, documentation-driven diagnostics tool for Windows storage systems. Its architecture is built around strict separation of concerns, reproducible behavior, and a stable module hierarchy shared across multiple repositories.

## 1. High-Level Design

DiskAssignmentStatus is composed of three independent layers:
- Discovery: Collect raw system facts.
- Evaluation: Apply deterministic rules to interpret those facts.
- Reporting: Render output using SharedModules logging and trace.

Each layer is isolated and side-effect-free except Reporting. All cross-cutting concerns such as logging, trace, and private path resolution are provided by SharedModules.

## 2. Layer Responsibilities

### 2.1 Discovery Layer

The Discovery layer gathers raw information from Windows:
- Physical disks (Get-Disk)
- Partitions (Get-Partition)
- Volumes (Get-Volume)
- Windows RE configuration (reagentc.exe /info)
- BCD enumeration (bcdedit /enum all /v)

Discovery returns structured objects only. It does not log, trace, evaluate, classify, write output, or perform fallback logic. Recovery probing is performed by RecoveryEvaluation atoms, not by Discovery.

### 2.2 Evaluation Layer

The Evaluation layer applies deterministic rules to the raw facts:
- Partition classification
- GPT and MBR metadata interpretation
- Alignment detection
- Recovery partition inference
- MSR handling
- Partition numbering
- Gap detection for non-partition regions

Evaluation is pure and side-effect-free.

Partition numbering rules:
- Real partitions start at 0 and increment.
- Non-partition gaps use "-".
- MSR and recovery partitions follow the same numbering rule.

Sorting rules:
- Primary: Disk
- Secondary: Offset

Recovery inference is performed by RecoveryEvaluation atoms.

### 2.3 Reporting Layer

The Reporting layer is responsible for all user-visible output:
- Fixed-width table rendering
- Logging via SharedModules LoggingContext
- Trace output via SharedModules TraceContext
- Formatting

Reporting is the only layer that emits output or performs side effects.

Removed behaviors:
- Write-RunLog
- Write-TraceLog
- Optional JSON or text output modes
- Local fallback logging

JSON output is produced exclusively by JSONState atoms.

## 3. Module Loading Model

DiskAssignmentStatus uses SharedModules for all cross-repository functionality.

### 3.1 PrivatePaths Module

Private path resolution is provided exclusively by:
- SharedModules, Modules, PrivatePaths.psm1

Local overrides and fallback logic are removed.

### 3.2 Logging and Trace Modules

Logging and trace are implemented exclusively through:
- SharedModules/Modules/Logging.psm1
- SharedModules/Modules/Trace.psm1

There is no local logging module, no legacy path probing, and no fallback writer. Failure to load SharedModules logging results in a deterministic error.

## 4. Script Structure

The main script (Source/DiskAssignmentStatus.ps1) orchestrates:
- Elevation check
- SharedModules loading (PrivatePaths, Logging, Trace)
- Discovery → Evaluation → RecoveryEvaluation → JSONState → Reporting pipeline
- Logging and trace activation via SharedModules
- Output rendering

The script contains no business logic. All logic resides in deterministic module atoms.

## 5. Output Model

The Reporting layer produces a fixed-width table with columns:
- Disk
- Ltr
- Part
- Offset
- A
- Size
- Part GUID
- Type
- Attrs
- Label
- FS
- Style

Sorting is by Disk and then Offset. Alignment indicator: A = aligned, blank = not aligned.

JSON output is produced by JSONState.psm1.

## 6. MSR Handling

- MSR partitions are hidden unless -ShowMSR is used.
- Shown MSR partitions use partition number 0.
- Multiple MSRs on a disk produce a warning via SharedModules logging.

## 7. Recovery Partition Detection

Recovery detection is performed by RecoveryEvaluation atoms.

The deterministic recovery pipeline:
- reagentc.exe /info
- bcdedit /enum all /v
- partition-to-volume mapping
- recovery inference via RecoveryEvaluation atoms

There is no fallback probing in the script.

## 8. Audit Trail

If repository audit logging is enabled, run metadata is written using SharedModules LoggingContext under:
docs/agent-runs/

## 9. Non-Goals

DiskAssignmentStatus does not:
- modify disks or partitions
- repair Windows RE
- change partition styles
- mount or unmount volumes
- perform recovery actions

It is strictly diagnostic.

