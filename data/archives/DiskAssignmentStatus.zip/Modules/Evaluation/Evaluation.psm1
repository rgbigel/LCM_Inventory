<#
    Module: Evaluation.psm1
    Version: 1.0.0
    Purpose: Apply deterministic evaluation rules to discovery objects.
    Caller Contract: Receives discovery data and returns structured evaluation results.
#>

$script:gptMap = @{
    "0FC63DAF-8483-4772-8E79-3D69D8477DE4" = "LX_FS"
    "0657FD6D-A4AB-43C4-84E5-0933C84B4F4F" = "LX_SW"
    "E6D6D379-F507-44C2-A23C-238F2A3DF928" = "LX_LV"
    "A19D880F-05FC-4D3B-A006-743F0F84911E" = "LX_RD"
    "C12A7328-F81F-11D2-BA4B-00A0C93EC93B" = "EFI"
    "E3C9E316-0B5C-4DB8-817D-F92DF00215AE" = "MSR"
    "EBD0A0A2-B9E5-4433-87C0-68B6B72699C7" = "WBS"
    "DE94BBA4-06D1-4D40-A16A-BFD50179D6AC" = "WinRec"
}

function Get-FileSystemType {
    [CmdletBinding()]
    param(
        [string]$TypeKey,
        [psobject]$Volume
    )

    if ($null -ne $Volume -and $Volume.FileSystem) {
        return $Volume.FileSystem
    }

    switch ($TypeKey) {
        "0FC63DAF-8483-4772-8E79-3D69D8477DE4" { return "EXT4" }
        "0657FD6D-A4AB-43C4-84E5-0933C84B4F4F" { return "SWAP" }
        "C12A7328-F81F-11D2-BA4B-00A0C93EC93B" { return "FAT32" }
        "E3C9E316-0B5C-4DB8-817D-F92DF00215AE" { return "MSR" }
        "DE94BBA4-06D1-4D40-A16A-BFD50179D6AC" { return "NTFS" }
        "EBD0A0A2-B9E5-4433-87C0-68B6B72699C7" { return "NTFS" }
        default { return "" }
    }
}

function Get-FriendlyPartitionType {
    [CmdletBinding()]
    param(
        [string]$TypeKey,
        [string]$DiskStyle
    )

    if ($script:gptMap.ContainsKey($TypeKey)) {
        return $script:gptMap[$TypeKey]
    }

    if ($DiskStyle -eq "MBR") {
        return "-"
    }

    return "Unknown"
}

function Invoke-DiskAssignmentEvaluation {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [psobject]$DiscoveryData,
        [switch]$ShowMSR
    )

    $results  = @()
    $msrCounts = @{}

    $grouped = $DiscoveryData.Partitions | Group-Object DiskNumber
    foreach ($group in $grouped) {
        $diskNumOriginal = [int]$group.Name
        $diskStyle = $DiscoveryData.DiskStyleMap[$diskNumOriginal]
        $sortedParts = $group.Group | Sort-Object Offset

        $msrList = $sortedParts | Where-Object {
            ($_.GptType -replace '[{}]', '').ToUpper() -eq 'E3C9E316-0B5C-4DB8-817D-F92DF00215AE'
        }

        $msrCounts[$diskNumOriginal] = @($msrList).Count
        $partitionIndex = 1

        foreach ($part in $sortedParts) {
            $typeKey = ($part.GptType -replace '[{}]', '').ToUpper()
            $isMSR = ($typeKey -eq 'E3C9E316-0B5C-4DB8-817D-F92DF00215AE')
            if (-not $ShowMSR -and $msrCounts[$diskNumOriginal] -le 1 -and $isMSR) {
                continue
            }

            $newPartNum = if ($isMSR) { 0 } else { $partitionIndex; $partitionIndex++ }
            $key = "{0}-{1}" -f [int]$part.DiskNumber, [int]$part.PartitionNumber
            $vol = if ($DiscoveryData.VolumeMap.ContainsKey($key)) { $DiscoveryData.VolumeMap[$key] } else { $null }

            $driveLetter = $part.DriveLetter
            if ($driveLetter -eq [char]0) { $driveLetter = $null }
            if (-not $driveLetter -and $vol) {
                $driveLetter = $vol.DriveLetter
                if ($driveLetter -eq [char]0) { $driveLetter = $null }
            }

            $label = if ($vol) { $vol.FileSystemLabel } else { "" }
            if ($DiscoveryData.RecoveryMap.ContainsKey($key)) {
                $recoveryTag = $DiscoveryData.RecoveryMap[$key]
                if ([string]::IsNullOrWhiteSpace($label)) {
                    $label = $recoveryTag
                }
                else {
                    $label = "{0} {1}" -f $label, $recoveryTag
                }
            }

            $partGuid = [string]$part.Guid
            if (-not $partGuid) { $partGuid = "-" }

            $flags = @()
            if ($part.IsSystem) { $flags += 'S' }
            if ($part.IsHidden) { $flags += 'H' }
            $flagString = if ($flags.Count -gt 0) { $flags -join ',' } else { '' }

            $partitionStyle = if ($DiscoveryData.RamdiskPartKeys.ContainsKey($key)) { 'RAM' } else { $diskStyle }

            $results += [PSCustomObject]@{
                DiskNumber       = [int]$diskNumOriginal
                PartitionNumber  = $newPartNum
                Offset           = [uint64]$part.Offset
                IsAligned        = ($part.Offset % 1MB -eq 0)
                SizeBytes        = [uint64]$part.Size
                PartitionGuid    = $partGuid
                TypeName         = Get-FriendlyPartitionType -TypeKey $typeKey -DiskStyle $diskStyle
                Attrs            = $flagString
                FsType           = Get-FileSystemType -TypeKey $typeKey -Volume $vol
                DriveLetter      = $driveLetter
                Label            = $label
                PartitionStyle   = $partitionStyle
            }
        }
    }

    $multiMsrWarnings = @()
    foreach ($entry in $msrCounts.GetEnumerator() | Where-Object { $_.Value -gt 1 }) {
        $multiMsrWarnings += "Disk $($entry.Key): $($entry.Value) MSR partitions found (expected 1)"
    }

    return [PSCustomObject]@{
        Results           = $results
        MultiMsrWarnings  = $multiMsrWarnings
    }
}

Export-ModuleMember -Function Invoke-DiskAssignmentEvaluation
