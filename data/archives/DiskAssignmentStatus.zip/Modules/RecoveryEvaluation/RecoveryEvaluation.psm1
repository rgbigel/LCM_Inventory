<#
    Module: RecoveryEvaluation.psm1
    Version: 1.0.0
    Purpose: Evaluate WinRE validity, recovery partition presence, partition layout correctness, required fixes, and recommended action.
    Caller Contract: Receives discovery data and returns a structured recovery evaluation object.
#>

function Get-RecoveryEvaluation {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [psobject]$DiscoveryData
    )

    $recoveryPartitionType = 'DE94BBA4-06D1-4D40-A16A-BFD50179D6AC'
    $recoveryPartitions = $DiscoveryData.Partitions | Where-Object {
        ($_.GptType -replace '[{}]', '').ToUpper() -eq $recoveryPartitionType
    }

    $hasRecoveryPartition = ($recoveryPartitions.Count -gt 0)
    $hasValidWinRE = ($DiscoveryData.RecoveryMap.Keys.Count -gt 0)

    if (-not $hasRecoveryPartition) {
        $partitionLayoutStatus = 'MissingRecoveryPartition'
        $requiresFix = $true
        $recommendedAction = 'Create a recovery partition and register it with WinRE.'
    }
    elseif (-not $hasValidWinRE) {
        $partitionLayoutStatus = 'RecoveryPartitionUnmapped'
        $requiresFix = $true
        $recommendedAction = 'Repair the recovery partition mapping and enable WinRE.'
    }
    else {
        $partitionLayoutStatus = 'Valid'
        $requiresFix = $false
        $recommendedAction = 'No recovery action required.'
    }

    return [PSCustomObject]@{
        HasValidWinRE         = [bool]$hasValidWinRE
        HasRecoveryPartition  = [bool]$hasRecoveryPartition
        PartitionLayoutStatus = $partitionLayoutStatus
        RequiresFix           = [bool]$requiresFix
        RecommendedAction     = $recommendedAction
    }
}

Export-ModuleMember -Function Get-RecoveryEvaluation

