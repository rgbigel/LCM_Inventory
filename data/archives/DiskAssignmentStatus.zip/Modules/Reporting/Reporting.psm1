<#
    Module: Reporting.psm1
    Version: 1.0.0
    Purpose: Render evaluation results and emit logging/trace output.
    Caller Contract: Receives evaluation results and shared logging context; performs reporting only.
#>

function Center {
    [CmdletBinding()]
    param(
        [string]$Text,
        [int]$Width
    )

    if (-not $Text) { return ' ' * $Width }
    $pad = $Width - $Text.Length
    if ($pad -le 0) { return $Text }
    $left  = [math]::Floor($pad / 2)
    $right = $pad - $left
    return (' ' * $left) + $Text + (' ' * $right)
}

function Format-Size {
    [CmdletBinding()]
    param(
        [UInt64]$Bytes
    )

    if ($Bytes -ge 1TB) { return ('{0:N2} TB' -f ($Bytes / 1TB)) }
    if ($Bytes -ge 1GB) { return ('{0:N2} GB' -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ('{0:N2} MB' -f ($Bytes / 1MB)) }
    if ($Bytes -ge 1KB) { return ('{0:N2} KB' -f ($Bytes / 1KB)) }
    return ('{0} B' -f $Bytes)
}

function Render-DiskAssignmentReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [psobject]$EvaluationData,
        [Parameter(Mandatory = $true)]
        [psobject]$LogContext
    )

    $results = $EvaluationData.Results | Sort-Object DiskNumber, PartitionNumber
    $tableLines = @()

    foreach ($row in $results) {
        $diskCentered = Center $row.DiskNumber 6
        $partCentered = Center $row.PartitionNumber 6
        $ltrCentered  = Center $row.DriveLetter 3
        $offsetText   = Format-Size $row.Offset
        $alignedMark  = if ($row.IsAligned) { 'A' } else { '' }

        $tableLines += [PSCustomObject]@{
            Disk       = $diskCentered
            Ltr        = $ltrCentered
            Part       = $partCentered
            Offset     = $offsetText
            A          = $alignedMark
            Size       = Format-Size $row.SizeBytes
            'Part GUID' = $row.PartitionGuid
            Type       = $row.TypeName
            Attrs      = $row.Attrs
            Label      = $row.Label
            FS         = $row.FsType
            Style      = $row.PartitionStyle
        }
    }

    $output = $results | Format-Table `
        @{Label='Disk'; Expression={$_.Disk}; Width=6}, `
        @{Label='Ltr'; Expression={$_.Ltr}; Width=4}, `
        @{Label='Part'; Expression={$_.Part}; Width=6}, `
        @{Label='Offset'; Expression={$_.Offset}; Width=10; Alignment='Right'}, `
        @{Label='A'; Expression={$_.A}; Width=2}, `
        @{Label='Size'; Expression={$_.Size}; Width=10; Alignment='Right'}, `
        @{Label='Part GUID'; Expression={$_."Part GUID"}; Width=38}, `
        @{Label='Type'; Expression={$_.Type}; Width=6}, `
        @{Label='Attrs'; Expression={$_.Attrs}; Width=5}, `
        @{Label='Label'; Expression={$_.Label}; Width=30}, `
        @{Label='FS'; Expression={$_.FS}; Width=8}, `
        @{Label='Style'; Expression={$_.Style}; Width=6} | Out-String -Width 500

    Write-Output $output
    Write-LogMessage -Context $LogContext -Level 'INFO' -Message $output -EmitToHost:$false

    if ($EvaluationData.MultiMsrWarnings.Count -gt 0) {
        Write-Output ''
        Write-Output 'WARNING: Multiple MSR partitions detected:'
        Write-LogMessage -Context $LogContext -Level 'WARN' -Message 'WARNING: Multiple MSR partitions detected:'
        foreach ($warnLine in $EvaluationData.MultiMsrWarnings) {
            Write-Output $warnLine
            Write-LogMessage -Context $LogContext -Level 'WARN' -Message $warnLine
        }
    }
}

Export-ModuleMember -Function Center, Format-Size, Render-DiskAssignmentReport
