<#
    Module: Discovery.psm1
    Version: 1.0.0
    Purpose: Collect raw disk, partition, volume, and Windows RE discovery facts.
    Caller Contract: Returns a structured discovery object; performs no evaluation or reporting.
#>

function Get-VolumeSerialHex {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    try {
        $text = fsutil fsinfo volumeinfo $Path 2>$null | Out-String
        if ($text -match '(?im)^\s*Volume Serial Number\s*:\s*0x([0-9a-f]+)\s*$') {
            return $matches[1].ToLower()
        }
    }
    catch {
    }

    return $null
}

function Get-PartitionMetaBySerial {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object[]]$Partitions
    )

    $map = @{}
    foreach ($partition in $Partitions) {
        foreach ($accessPath in @($partition.AccessPaths | Where-Object { $_ -match '^\\\\\\\\\?\\Volume\{[^}]+\}\\$' })) {
            $serial = Get-VolumeSerialHex -Path $accessPath
            if (-not $serial) { continue }

            if (-not $map.ContainsKey($serial)) {
                $map[$serial] = [PSCustomObject]@{
                    DiskNumber      = [int]$partition.DiskNumber
                    PartitionNumber = [int]$partition.PartitionNumber
                }
            }
        }
    }

    return $map
}

function Get-HarddiskVolumeToDiskPartMap {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object[]]$Partitions
    )

    $map = @{}
    if (-not ([System.Management.Automation.PSTypeName]'DiskAssignNative').Type) {
        $code = @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public class DiskAssignNative {
    [DllImport("kernel32.dll", CharSet=CharSet.Auto, SetLastError=true)]
    public static extern uint QueryDosDevice(string lpDeviceName, StringBuilder lpTargetPath, int ucchMax);
}
'@
        try { Add-Type -TypeDefinition $code -ErrorAction Stop } catch {}
    }

    foreach ($partition in $Partitions) {
        foreach ($accessPath in @($partition.AccessPaths)) {
            if ($accessPath -notmatch '^\\\\\\\\\?\\(Volume\{[^}]+\})\\$') { continue }

            $volumeDeviceName = $matches[1]
            $sb = New-Object System.Text.StringBuilder 260
            try {
                $ret = [DiskAssignNative]::QueryDosDevice($volumeDeviceName, $sb, $sb.Capacity)
            } catch { continue }
            if ($ret -eq 0) { continue }

            $ntPath = $sb.ToString().Split([char]0)[0]
            if ($ntPath -notmatch '^\\Device\\HarddiskVolume\d+$') { continue }

            $key = "{0}-{1}" -f [int]$partition.DiskNumber, [int]$partition.PartitionNumber
            $map[$ntPath] = $key
        }
    }

    return $map
}

function Normalize-AccessPath {
    [CmdletBinding()]
    param(
        [AllowEmptyString()]
        [string]$Path
    )

    if ([string]::IsNullOrWhiteSpace($Path)) {
        return $null
    }

    if ($Path.Length -eq 2 -and $Path[1] -eq ':') {
        return "{0}\\" -f $Path
    }

    return $Path.TrimEnd('\\') + '\\'
}

function Build-VolumeMap {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object[]]$Volumes,
        [Parameter(Mandatory = $true)]
        [object[]]$Partitions
    )

    $volumeByAccessPath = @{}
    foreach ($volume in $Volumes) {
        foreach ($candidatePath in @($volume.Path, $volume.UniqueId)) {
            $normalizedPath = Normalize-AccessPath -Path $candidatePath
            if ($normalizedPath) {
                $volumeByAccessPath[$normalizedPath] = $volume
            }
        }

        if ($volume.DriveLetter) {
            $drivePath = Normalize-AccessPath -Path ("{0}:" -f $volume.DriveLetter)
            if ($drivePath) {
                $volumeByAccessPath[$drivePath] = $volume
            }
        }
    }

    $volumeMap = @{}
    foreach ($partition in $Partitions) {
        $partitionKey = "{0}-{1}" -f [int]$partition.DiskNumber, [int]$partition.PartitionNumber
        foreach ($accessPath in @($partition.AccessPaths)) {
            $normalizedPath = Normalize-AccessPath -Path $accessPath
            if ($normalizedPath -and $volumeByAccessPath.ContainsKey($normalizedPath)) {
                $volumeMap[$partitionKey] = $volumeByAccessPath[$normalizedPath]
                break
            }
        }

        if (-not $volumeMap.ContainsKey($partitionKey) -and $partition.DriveLetter -and $partition.DriveLetter -ne [char]0) {
            $drivePath = Normalize-AccessPath -Path ("{0}:" -f $partition.DriveLetter)
            if ($drivePath -and $volumeByAccessPath.ContainsKey($drivePath)) {
                $volumeMap[$partitionKey] = $volumeByAccessPath[$drivePath]
            }
        }
    }

    return $volumeMap
}

function Build-RecoveryMap {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object[]]$Partitions,
        [Parameter(Mandatory = $true)]
        [object[]]$Volumes
    )

    $recoveryMap = @{}
    $windowsTargets = New-Object System.Collections.Generic.List[string]
    if ($env:SystemRoot) { $windowsTargets.Add($env:SystemRoot) }
    foreach ($v in $Volumes) {
        if ($v.DriveLetter) {
            $candidate = "{0}:\Windows" -f $v.DriveLetter
            try {
                if (Test-Path "$candidate\System32\Config\SYSTEM" -ErrorAction Stop) {
                    $windowsTargets.Add($candidate)
                }
            }
            catch {
            }
        }
    }

    try {
        $reInfoCurrent = & reagentc.exe /info 2>$null
        foreach ($line in $reInfoCurrent) {
            if ($line -match 'Windows RE location:\s+\\\\\\\\\?\\GLOBALROOT\\device\\harddisk(\d+)\\partition(\d+)') {
                $rd = [int]$Matches[1]
                $rp = [int]$Matches[2]
                $rKey = "{0}-{1}" -f $rd, $rp
                $recoveryMap[$rKey] = "D{0}P{1} # RecPartition" -f $rd, $rp
            }
        }
    } catch {}

    $targets = $windowsTargets | ForEach-Object { $_.TrimEnd('\\') } | Sort-Object -Unique
    foreach ($target in $targets) {
        $reInfo = & reagentc.exe /info /target $target 2>$null
        if (-not $reInfo) { continue }
        foreach ($line in $reInfo) {
            if ($line -match 'Windows RE location:\s+\\\\\\\\\?\\GLOBALROOT\\device\\harddisk(\d+)\\partition(\d+)') {
                $rd = [int]$Matches[1]
                $rp = [int]$Matches[2]
                $rKey = "{0}-{1}" -f $rd, $rp
                $designation = "D{0}P{1} # RecPartition" -f $rd, $rp
                if ($recoveryMap.ContainsKey($rKey)) {
                    if ($recoveryMap[$rKey] -notlike "*$designation*") {
                        $recoveryMap[$rKey] = "{0}|{1}" -f $recoveryMap[$rKey], $designation
                    }
                } else {
                    $recoveryMap[$rKey] = $designation
                }
            }
        }
    }

    $ramdiskPartKeys = @{}
    try {
        $bcdEditExe = Join-Path $env:WINDIR "System32\bcdedit.exe"
        $bcdText = & $bcdEditExe /enum all /v 2>&1 | Out-String
        if ($LASTEXITCODE -eq 0 -and $bcdText) {
            $hdVolToPartKey = Get-HarddiskVolumeToDiskPartMap -Partitions $Partitions
            $deviceById = @{}
            $recoveryByOsId = @{}
            $blocks = [regex]::Split($bcdText.Trim(), "(?:`r?`n){2,}")
            foreach ($block in $blocks) {
                if ($block -notmatch '(?im)^\s*identifier\s+(\{[^}]+\})') { continue }
                $id = $matches[1].ToLower()
                if ($block -match '(?im)^\s*device\s+(.+)$') { $deviceById[$id] = $matches[1].Trim() }
                if ($block -match '(?im)^\s*recoverysequence\s+(\{[^}]+\})') { $recoveryByOsId[$id] = $matches[1].ToLower() }
            }

            foreach ($recoveryId in ($recoveryByOsId.Values | Select-Object -Unique)) {
                if (-not $deviceById.ContainsKey($recoveryId)) { continue }
                $dev = $deviceById[$recoveryId]
                $resolvedKey = $null

                if ($dev -match '(?i)partition=\\\\\\\\\?\\GLOBALROOT\\device\\harddisk(\d+)\\partition(\d+)') {
                    $resolvedKey = "{0}-{1}" -f [int]$matches[1], [int]$matches[2]
                }
                elseif ($dev -match '(?i)partition=\\Device\\Harddisk(\d+)\\Partition(\d+)') {
                    $resolvedKey = "{0}-{1}" -f [int]$matches[1], [int]$matches[2]
                }
                elseif ($dev -match '(?i)ramdisk=\[\\Device\\(HarddiskVolume\d+)\]') {
                    $hdVol = "\\Device\\" + $matches[1]
                    if ($hdVolToPartKey.ContainsKey($hdVol)) {
                        $resolvedKey = $hdVolToPartKey[$hdVol]
                        $ramdiskPartKeys[$resolvedKey] = $true
                    }
                }
                elseif ($dev -match '(?i)partition=(\\Device\\HarddiskVolume\d+)') {
                    $hdVol = $matches[1]
                    if ($hdVolToPartKey.ContainsKey($hdVol)) {
                        $resolvedKey = $hdVolToPartKey[$hdVol]
                    }
                }
                elseif ($dev -match '(?i)partition=([A-Z]):') {
                    $drive = $matches[1]
                    try {
                        $p = Get-Partition -DriveLetter $drive -ErrorAction Stop
                        $resolvedKey = "{0}-{1}" -f [int]$p.DiskNumber, [int]$p.PartitionNumber
                    }
                    catch {
                    }
                }

                if (-not $resolvedKey) { continue }
                $parts = $resolvedKey.Split('-')
                $designation = "D{0}P{1} # RecPartition" -f $parts[0], $parts[1]
                if ($recoveryMap.ContainsKey($resolvedKey)) {
                    if ($recoveryMap[$resolvedKey] -notlike "*$designation*") {
                        $recoveryMap[$resolvedKey] = "{0}|{1}" -f $recoveryMap[$resolvedKey], $designation
                    }
                }
                else {
                    $recoveryMap[$resolvedKey] = $designation
                }
            }
        }
    }
    catch {
    }

    return [PSCustomObject]@{
        RecoveryMap   = $recoveryMap
        RamdiskPartKeys = $ramdiskPartKeys
    }
}

function Get-DiskAssignmentDiscoveryData {
    [CmdletBinding()]
    param(
        [switch]$ShowMSR
    )

    $allDisks = Get-Disk
    $allParts = Get-Partition
    $allVols  = Get-Volume

    $diskStyleMap = @{}
    foreach ($d in $allDisks) {
        $diskStyleMap[[int]$d.Number] = [string]$d.PartitionStyle
    }

    $volumeMap = Build-VolumeMap -Volumes $allVols -Partitions $allParts
    $recoveryData = Build-RecoveryMap -Partitions $allParts -Volumes $allVols

    return [PSCustomObject]@{
        Disks            = $allDisks
        Partitions        = $allParts
        Volumes          = $allVols
        DiskStyleMap     = $diskStyleMap
        VolumeMap        = $volumeMap
        RecoveryMap      = $recoveryData.RecoveryMap
        RamdiskPartKeys  = $recoveryData.RamdiskPartKeys
    }
}

Export-ModuleMember -Function Get-DiskAssignmentDiscoveryData
