<#
    Module: JSONState.psm1
    Version: 1.0.0
    Purpose: Construct, normalize, validate, serialize, stamp, merge, and emit deterministic JSON state.
    Caller Contract: Receives discovery, evaluation, and recovery evaluation data and emits a JSON state file.
#>

function Build-StateModel {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [psobject]$DiscoveryData,
        [Parameter(Mandatory = $true)]
        [psobject]$EvaluationData,
        [Parameter(Mandatory = $true)]
        [psobject]$RecoveryEvaluationData
    )

    return [PSCustomObject]@{
        Timestamp              = (Get-Date).ToString('o')
        Discovery              = $DiscoveryData
        Evaluation             = $EvaluationData
        RecoveryEvaluation     = $RecoveryEvaluationData
    }
}

function Normalize-StateModel {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [psobject]$StateModel
    )

    $normalized = [ordered]@{
        Timestamp          = $StateModel.Timestamp
        Discovery          = $StateModel.Discovery
        Evaluation         = $StateModel.Evaluation
        RecoveryEvaluation = $StateModel.RecoveryEvaluation
    }

    return [PSCustomObject]$normalized
}

function Validate-StateSchema {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [psobject]$StateModel
    )

    if (-not $StateModel.PSObject.Properties.Match('Timestamp')) {
        throw 'State model is missing Timestamp.'
    }
    foreach ($field in @('Discovery', 'Evaluation', 'RecoveryEvaluation')) {
        if (-not $StateModel.PSObject.Properties.Match($field)) {
            throw "State model is missing $field."
        }
    }

    return $true
}

function Serialize-ToJson {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [psobject]$StateModel
    )

    return $StateModel | ConvertTo-Json -Depth 10 -Compress
}

function Stamp-VersionMetadata {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [psobject]$StateModel,
        [Parameter(Mandatory = $true)]
        [string]$Version
    )

    $StateModel.Version = $Version
    return $StateModel
}

function Merge-RecoveryInference {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [psobject]$EvaluationData,
        [Parameter(Mandatory = $true)]
        [psobject]$RecoveryEvaluationData
    )

    $properties = @{}
    foreach ($prop in $EvaluationData.PSObject.Properties) {
        $properties[$prop.Name] = $prop.Value
    }
    $properties['RecoveryEvaluation'] = $RecoveryEvaluationData
    return [PSCustomObject]$properties
}

function Emit-JsonFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [Parameter(Mandatory = $true)]
        [string]$JsonContent
    )

    $dir = Split-Path -Path $Path -Parent
    if (-not (Test-Path -LiteralPath $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }

    $JsonContent | Out-File -FilePath $Path -Encoding UTF8 -Force
    return $Path
}

Export-ModuleMember -Function Build-StateModel, Normalize-StateModel, Validate-StateSchema, Serialize-ToJson, Stamp-VersionMetadata, Merge-RecoveryInference, Emit-JsonFile

