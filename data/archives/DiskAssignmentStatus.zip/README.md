# DiskAssignmentStatus — README (Version 2.0.1)

DiskAssignmentStatus is a deterministic diagnostics tool for Windows storage systems. It evaluates disk layout, partition structure, recovery configuration, and Windows RE status using a reproducible module pipeline.

## 1. Purpose

DiskAssignmentStatus answers questions such as:
- How is this disk partitioned?
- Are partitions aligned?
- Is Windows RE configured correctly?
- Where is the recovery partition?
- Are there gaps or unusual regions?
- Does the system meet documented requirements?

The tool is strictly diagnostic. It does not modify the system.

## 2. Features

- Deterministic output
- Fixed-width table rendering
- JSON output
- Recovery inference via RecoveryEvaluation atoms
- SharedModules\ \(runtime-plane\) logging and trace
- Strict layer separation
- No fallback logic
- No local wrappers
- No optional modes

## 3. Usage

Run the tool from an elevated PowerShell session:
DiskAssignmentStatus.ps1

Supported parameters:
- -Json
- -Verbose
- -t
- -l
- -ShowMSR

Behavioral rule:
- The -t flag automatically enables -l

Output formats:
- Fixed-width table
- JSON

## 4. Architecture Overview

The tool uses a three-layer architecture:
- Discovery: collect raw facts
- Evaluation: interpret facts deterministically
- Reporting: render output using SharedModules\ \(runtime-plane\)

Recovery detection is performed by RecoveryEvaluation atoms. JSON output is produced by JSONState atoms.

The main script is a thin orchestrator.

## 5. SharedModules\ \(runtime-plane\)

SharedModules\ \(runtime-plane\) provides:
- LoggingContext
- TraceContext
- PrivatePaths
- Version metadata

Local logging modules, fallback writers, and legacy wrappers are removed.

## 6. Output

The fixed-width table includes:
- Disk
- Ltr
- Part
- Offset
- A
- Size
- Part GUID
- Type
- Attrs
- Label
- FS
- Style

Rows are sorted by Disk and Offset. Alignment indicator: A = aligned, blank = not aligned.

JSON output is deterministic and produced by JSONState atoms.

## 7. Recovery Detection

Recovery detection uses:
- reagentc.exe /info
- bcdedit /enum all /v
- partition-to-volume mapping

Inference is performed by RecoveryEvaluation atoms.

## 8. Requirements Summary

DiskAssignmentStatus must:
- behave deterministically
- preserve strict layer separation
- use SharedModules\ \(runtime-plane\) for logging and trace
- produce structured evaluation objects
- generate JSON and table output
- fail deterministically on errors
- follow documentation as the authoritative source

## 9. Non-Goals

The tool does not:
- modify disks
- repair Windows RE
- change partition styles
- mount or unmount volumes
- perform recovery actions

It is strictly diagnostic.

## Structural Overview
- Install/: installation layer
- Source/: orchestrator layer
- Source/Modules/: combined execution layer
- Modules/*.ps1m: pure modules
- logs/agent-runs/: audit layer

