# MODULE: RemediationAtoms.proposal
# PURPOSE: Define repo-specific remediation atoms that operate above evaluation-level atoms. These atoms represent corrective action determination and recommended remediation guidance for DiskAssignmentStatus.
# PATH: Methods\CookBooks\20260715_181000 RemediationAtoms.proposal.md
# VERSION: 1.0.0
# CHANGELOG:
# - 1.0.0 Initial creation as separate remediation atom file.
# - 1.0.0 Excluded remediation atoms from ATOMS.proposal.md according to alignment rules.
# - 1.0.0 Added Step 1 and Step 2 references.

# SECTION: OVERVIEW
Remediation atoms operate at a higher conceptual level than evaluation atoms. Evaluation atoms determine factual state. Remediation atoms determine corrective action. Remediation atoms must reference Step 1 discrepancies and Step 2 corrections. Remediation atoms must remain proposal-only until approved by an agent cycle.

# SECTION: REMEDIATION_ATOM_REQUIRES_FIX_ASSESSMENT
AtomName: RequiresFixAssessment
Responsibility: Determine whether the current disk and recovery configuration requires corrective action.
Inputs: partition layout status, WinRE validation status, recovery partition mapping.
Outputs: boolean RequiresFix indicator.
Boundaries: repo-specific remediation atom; not pipeline-level; not SharedModules-level.
Step1Reference: DISCREPANCY_06_ATOMS_AGENTS_NOT_OPERATIONALIZED.
Step2Reference: CORRECTION_06_OPERATIONALIZE_ATOMS_AND_AGENTS.
Reason: This atom represents a remediation decision that is specific to DiskAssignmentStatus and must not be included in pipeline-level ATOMS.md.

# SECTION: REMEDIATION_ATOM_RECOMMENDED_RECOVERY_ACTION
AtomName: RecommendedRecoveryAction
Responsibility: Generate a recommended corrective action based on detection of WinRE or partition layout issues.
Inputs: evaluation status flags, recovery partition location, layout compliance results.
Outputs: textual RecommendedAction guidance.
Boundaries: repo-specific remediation atom; not pipeline-level; not SharedModules-level.
Step1Reference: DISCREPANCY_06_ATOMS_AGENTS_NOT_OPERATIONALIZED.
Step2Reference: CORRECTION_06_OPERATIONALIZE_ATOMS_AND_AGENTS.
Reason: Recommendation generation is a repo-specific extension beyond deterministic evaluation atoms and must remain proposal-only.

# SECTION: BOUNDARIES
Remediation atoms must not be added to ATOMS.md.
Remediation atoms must not modify SharedModules.
Remediation atoms must not infer new pipeline-level behavior.
Remediation atoms must not be executed without an agent cycle.
Remediation atoms must remain proposal-only until approved.

# END_OF_REMEDIATION_ATOMS
