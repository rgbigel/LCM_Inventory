# File: PowerShellRules.md
# Version: 1.1.0
# Created: 2026-07-17
# Updated: 2026-07-17
#
# Purpose:
#   Authoritative PowerShell rule set for deterministic, safe, ASCII-compliant script generation.
#
# Notes:
#   Stored in Methods/Rules/PowerShellRules.md.
#
# Changelog:
#   1.1.0 - Added CRLF newline rule; allowed umlauts in comments; corrected ascii-default phrasing.
#   1.0.0 - Initial reconstruction from ExplicitFacts.

POWERSHELL-RULES
- ascii-default: ASCII required; umlauts allowed in literal strings and comments
- utf8-without-bom: scripts must be UTF-8 without BOM
- newline-crlf: scripts must end with CRLF
- comments-english-only: comments must be written in English
- no-backticks: backticks forbidden in all contexts
- no-interpolated-calls: forbid method calls inside interpolated strings
- assign-$_-first: always assign $_ to a variable before use
- constant-string-apostrophes: use single ASCII apostrophe; avoid doubled apostrophes
- no-non-ascii-identifiers: identifiers must be ASCII-only
- no-hidden-state: forbid hidden pipeline or implicit variable usage
- deterministic-output: identical input → identical output

SCRIPT-HEADER-RULES
- script-header-required: every script must contain a header block
- script-header-format: header must use <# ... #> block comment format
- script-header-fields:
  - Module:
  - Purpose:
  - Path:
  - Authors:
  - Version:
  - Changelog:
- header-placement-no-param: if no param() block exists, header must be at top of file
- header-placement-with-param: if param() block exists, header must be immediately after param()
- module-name-extension: Module field must include file extension (e.g., .ps1, .psm1)

STRUCTURAL-RULES
- indent-2: indentation level is exactly 2 spaces
- no-tabs: indentation uses spaces only
- max-line-length: 120 characters
- no-trailing-whitespace
- deterministic-structure: stable ordering of sections and blocks

USER-EXPOSED-MODULE-RULES
- help-path: -h output must include full path to help-<module>.md
- authors-field-required: Authors field must be present even if single author
- version-required: Version field must be present and semantic (x.y.z)

METADATA
- scope: repo-level rule set
- location: Methods/Rules/PowerShellRules.md
