# File: JsonRules.md
# Version: 1.1.0
# Created: 2026-07-17
# Updated: 2026-07-17
#
# Purpose:
#   Authoritative JSON rule set for deterministic parsing, formatting, and validation.
#
# Notes:
#   Stored in Methods/Rules/JsonRules.md.
#
# Changelog:
#   1.1.0 - Added LF-only newline rule; removed misplaced .md exception; clarified ascii-strict-json.
#   1.0.1 - Added indent-2-json; removed .md ASCII exception.
#   1.0.0 - Initial reconstruction from ExplicitFacts.

JSON-RULES
- ascii-default: ASCII required unless explicit exception applies
- ascii-strict-json: JSON files must remain strict ASCII except for UTF-8 encoded content explicitly allowed by schema
- utf8-required: JSON must be valid UTF-8 without BOM
- newline-lf-json: JSON files must end with LF
- no-comments: JSON must never contain // or /* */ comments
- quoted-keys: all keys must use double quotes
- quoted-strings: all string values must use double quotes
- no-trailing-commas: arrays and objects must not end with commas
- no-duplicate-keys: objects must not contain repeated keys
- spaces-only: indentation uses spaces, never tabs
- indent-2-json: indentation level is exactly 2 spaces
- booleans-lowercase: true, false
- null-lowercase: null
- no-leading-zeros: numbers must not contain leading zeros
- no-nan-infinity: NaN, Infinity, -Infinity forbidden
- array-type-consistency: arrays must not mix unrelated types unless schema requires it
- alphabetical-keys: objects sorted alphabetically unless semantic order required
- max-line-length: 120 characters
- no-trailing-whitespace
- pretty-print-default: pretty-print unless minimization explicitly requested
- minimize-on-demand: minimization only when explicitly requested
- escape-rfc8259: escape sequences must follow RFC 8259
- no-comment-strings: strings must not contain disguised comments
- no-bom: BOM markers forbidden
- deterministic-output: same input ? same output
- schema-consistency: must match schema when provided
- no-platform-paths: no platform-specific path separators unless escaped
- no-control-chars: forbid control chars below U+0020
- no-trailing-zeros-decimals
- no-unescaped-surrogates: forbid unescaped Unicode surrogate halves
- validate-before-output: JSON must be validated before output

CONSTANT-STRING-RULES
- constant-string-apostrophes: use single ASCII apostrophe; avoid doubled apostrophes

METADATA
- scope: repo-level rule set
- location: Methods/Rules/JsonRules.md
