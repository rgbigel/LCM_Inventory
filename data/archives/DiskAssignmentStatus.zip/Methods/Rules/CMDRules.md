# File: CMDRules.md
# Version: 1.1.0
# Created: 2026-07-17
# Updated: 2026-07-17
#
# Purpose:
#   Authoritative CMD rule set for deterministic, ASCII-safe, Windows-native batch script generation.
#
# Notes:
#   Stored in Methods/Rules/CMDRules.md.
#
# Changelog:
#   1.1.0 - Added CRLF newline rule; confirmed ASCII-only; aligned with ExplicitFacts.
#   1.0.0 - Initial reconstruction from ExplicitFacts.

CMDRules
- ascii-only: CMD scripts must be strict ASCII (0x00–0x7F)
- no-unicode: Unicode characters forbidden
- no-typographic-symbols: forbid arrows, bullets, umlauts, fancy punctuation
- utf8-without-bom: scripts must be UTF-8 without BOM
- newline-crlf: scripts must end with CRLF
- no-tabs: indentation uses spaces only
- indent-2: indentation level is exactly 2 spaces
- deterministic-output: identical input → identical output

SCRIPT-HEADER-RULES
- header-required: every CMD script must contain a REM-based header
- header-format: header must use REM for all lines
- header-fields:
  - Module: <filename.cmd>
  - Purpose: <description>
  - Path: <full path>
  - Authors: Rolf + Copilot
  - Version: <version>
  - Changelog:
      <version> — <description>
- header-placement: header must be at the top of the file
- header-ascii-only: header must be strict ASCII

PARSER-SAFETY-RULES
- no-nested-expansions: never use nested %variable% expansions
- delayed-expansion-explicit: enable/disable delayed expansion only when explicitly required
- no-bang-vars: avoid !variable! unless delayed expansion is explicitly enabled
- quote-paths: always quote paths with spaces using double quotes
- no-implicit-expansion-order: never rely on implicit variable expansion order
- minimal-escaping: avoid ^ escaping unless absolutely necessary
- no-special-chars-in-vars: never use & or | inside variable values
- comment-style-consistency: avoid mixing REM and :: in the same file

STRUCTURAL-RULES
- exit-b: use EXIT /B to return from scripts
- call-only-when-needed: use CALL only when recursion or re-entry is required
- setlocal-required: use SETLOCAL/ENDLOCAL when modifying environment variables
- no-fallthrough: avoid implicit fall-through between logic blocks
- max-line-length: 120 characters
- no-trailing-whitespace

USER-EXPOSED-MODULE-RULES
- help-switch: scripts that accept parameters must implement:
    script.cmd -h
    script.cmd -help
- help-output: -h must output:
    - header fields
    - parameter list
    - usage examples
- help-ascii-only: help output must be ASCII-only

DOCUMENTATION-RULES
- help-file-required: each CMD module must have a help-<module>.txt file
- help-file-ascii-only: help file must be ASCII-only
- help-file-fields:
    - parameters
    - return codes
    - examples
    - version

VERSION-RULES
- version-deterministic: version output must be deterministic
- version-match-header: version must match the Version field in the header
- version-top-of-log: version must appear at the top of any log output
- version-ascii-only: version must be ASCII-only

METADATA
- scope: repo-level rule set
- location: Methods/Rules/CMDRules.md
