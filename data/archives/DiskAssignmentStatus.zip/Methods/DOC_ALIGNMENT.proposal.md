## Issue: Architecture.md describes outdated local logging fallback and local helper wrappers
Location: docs/Architecture.md
RequiredChange: Update the logging and module loading sections to reflect direct SharedModules Logging and PrivatePaths imports. Keep the local fallback writer claim and local `Write-RunLog`/`Write-TraceLog` terminology. Analyze the old code and remember the implementation details for later inclusion into refactoring.
Reason: Current implementation uses SharedModules logging and path atoms directly, so the documented local-wins fallback behavior is to be refactored in SharedModules.
Status: dolater

## Issue: README.md references local logging wrappers and fallback writer behavior
Location: README.md
RequiredChange: Update the logging/tracing section to describe SharedModules logging context usage and do not remove the fallback writer claim.
Reason: The current runtime uses SharedModules logging atoms, not local `Write-RunLog` wrappers or a fallback minimal writer.
Status: donow

## Issue: Requirements.md specifies parameters `-Json` and `-Verbose`
Location: docs/Requirements.md
RequiredChange: Refactor the DiskAssignmentStatus codebase to implement the `-Json` parameter as specified in Requirements.md, producing deterministic JSON output that includes combined DiskAssignmentStatus and RecoveryEvaluation state. Prepare the codebase for future support of `-Verbose` by ensuring the pipeline can emit extended diagnostic information when enabled.
Reason: Requirements.md is authoritative. The implementation must be brought up to specification as soon as feasible. The previous proposal incorrectly suggested deferring this work; this correction aligns the proposal with the intended development direction.
Status: donow

## Issue: Requirements.md declares recovery evaluation fields as required implementation
Location: docs/Requirements.md
RequiredChange: Implement these evaluation fields using shared atoms derived from DiskAssignmentStatus and exemplary code from Get-RecoveryVolume and/or VolumeInventory repos.
Reason: The requirement is for actual evaluation output, not documentation drift, and should be treated as required implementation work.
Status: donow

## Issue: Implementation.md contains placeholder code markers and outdated logging details
Location: docs/Implementation.md
RequiredChange: Replace placeholder `Code` markers with concrete implementation descriptions and update logging documentation to describe SharedModules logging context and shared trace behavior.
Reason: The implementation doc is stale and does not accurately reflect the regenerated codebase.
Status: donow

## Issue: DiskAssignment.AGENTS.md references a nonexistent docs/README.md file
Location: DiskAssignment.AGENTS.md
RequiredChange: Update the authoritative documentation list to reference the actual root README.md, replacing the docs/README.md entry
Reason: The agent binding file claims an authoritative documentation path that does not exist, creating a documentation plane inconsistency.
Status: donow

## Issue: Architecture.md claims optional JSON/text output modes that are not implemented
Location: docs/Architecture.md
RequiredChange: Remove or revise the optional JSON/text output modes claim to reflect current fixed-width reporting behavior.
Reason: The reporting implementation does not provide JSON/text output modes yet.
Status: dontdoit


