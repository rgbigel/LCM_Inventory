# TOOLS.md — Version 3.0.0
# DiskAssignmentStatus — Workspace Tooling Integration (Cycle-2 Architecture)
# ascii-only, deterministic-structure, technical-flavor

## 1. PURPOSE
Define workspace-level tooling available to DiskAssignmentStatus, including search tools, diff tools, and external utilities used by Methods-plane workflows, VS Code agents, and regeneration tasks.

## 2. SOURCE
- durable-memory-file: .copilot/MyTOOLS.md
- update-policy: manual
- scope: workspace-root
- version: 3.0.0

## 3. TOOL-CATEGORIES
- search-tools
- diff-tools

## 4. SEARCH-TOOLS
### TOOL: everything.exe
- type: search-indexer
- path: C:\Tools\Everything\everything.exe
- usage: fast file search; VS Code integration
- version: 1.0.0

### TOOL: es.exe
- type: cli-search
- path: C:\Tools\Everything\es.exe
- usage: command-line search; VS Code tasks
- version: 1.0.0

## 5. DIFF-TOOLS
### TOOL: BeyondCompare5
- type: diff-merge
- path: C:\Tools\BeyondCompare5\BCompare.exe
- usage: file diff, folder diff, merge tool; VS Code integration
- version: 5.0.0

## 6. METHODS-PLANE INTEGRATION
- search-tools used for:
  - workspace scans
  - misplaced-file detection
  - regeneration input discovery
  - sync validation
- diff-tools used for:
  - deterministic diff review
  - merge operations
  - Methods-plane proposal comparison

## 7. AGENT-INTEGRATION
- VS Code agents may invoke:
  - everything.exe for fast search
  - es.exe for CLI search tasks
  - BeyondCompare5 for diff/merge operations

## 8. INVARIANTS
- ascii-only
- deterministic-output
- reproducible-results
- strict-plane-boundaries
- workspace-root authority

STATUS: active
