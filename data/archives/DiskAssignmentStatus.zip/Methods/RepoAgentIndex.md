# MODULE: RepoAgentIndex
# PURPOSE: Provide the authoritative index of refactoring agents for DiskAssignmentStatus. RepoAgentIndex.md lists all agents approved for use in <repo>.DocPhase and describes their responsibilities, boundaries, and Step 1 and Step 2 references.
# PATH: Methods\RepoAgentIndex.md
# VERSION: 4.0.0
# CHANGELOG:
# - 4.0.0 Updated to align with DocsRefactoringCookbook.
# - 4.0.0 Updated to align with AGENTS.md.
# - 4.0.0 Updated terminology references.
# - 4.0.0 Removed remediation agents.
# - 4.0.0 Removed SharedModules agents.
# - 4.0.0 Rebuilt structure to match cyclic refactoring model.

# SECTION: OVERVIEW
RepoAgentIndex.md defines the complete set of refactoring agents available for DiskAssignmentStatus. Each agent represents a deterministic, reproducible, context-free refactoring cycle. Each agent must reference Step 1 discrepancies and Step 2 corrections. Each agent must operate inside <repo>.DocPhase. RepoAgentIndex.md must remain consistent with AGENTS.md and ACTION_QUEUE.md. RepoAgentIndex.md must not contain proposals. RepoAgentIndex.md must not contain remediation agents. RepoAgentIndex.md must not contain SharedModules agents.

# SECTION: AGENT_LOCAL_LOGGING_CLEANUP
AgentName: LocalLoggingCleanup
Responsibility: Remove legacy local logging wrappers and align DiskAssignmentStatus with SharedModules logging lifecycle.
Step1Reference: DISCREPANCY_03_CROSS_REPO_INTEGRATION_INCOMPLETE
Step2Reference: CORRECTION_03_ALIGN_SHARED_MODULES_INTEGRATION
AtomReference: LocalLoggingContextInitialization, LocalFallbackWriterRemoval
Boundaries: documentation-plane only; must not modify SharedModules; must not modify code.

# SECTION: AGENT_LOCAL_PATH_RESOLUTION_ALIGNMENT
AgentName: LocalPathResolutionAlignment
Responsibility: Remove legacy path resolution logic and align documentation with SharedModules PrivatePaths resolution.
Step1Reference: DISCREPANCY_02_REPO_STRUCTURE_NOT_RE_ANCHORED
Step2Reference: CORRECTION_02_REBUILD_REPO_STRUCTURE_MODEL
AtomReference: LocalPathResolutionCleanup
Boundaries: documentation-plane only; must not modify SharedModules; must not modify code.

# SECTION: AGENT_RECOVERY_EVALUATION_ALIGNMENT
AgentName: RecoveryEvaluationAlignment
Responsibility: Align recovery evaluation documentation with Requirements.md and actual implementation boundaries.
Step1Reference: DISCREPANCY_01_DOCUMENTATION_IMPLEMENTATION_DRIFT
Step2Reference: CORRECTION_01_RE_ANCHOR_DOCUMENTATION
AtomReference: RecoveryEvaluationAlignment
Boundaries: documentation-plane only; must not modify code.

# SECTION: AGENT_JSON_NORMALIZATION_ALIGNMENT
AgentName: JSONNormalizationAlignment
Responsibility: Align JSON normalization documentation with Requirements.md and cross-repo normalization rules.
Step1Reference: DISCREPANCY_01_DOCUMENTATION_IMPLEMENTATION_DRIFT
Step2Reference: CORRECTION_02_REBUILD_REPO_STRUCTURE_MODEL
AtomReference: JSONStateNormalization
Boundaries: documentation-plane only; must not modify code.

# SECTION: BOUNDARIES
RepoAgentIndex.md must not contain remediation agents. RepoAgentIndex.md must not contain SharedModules agents. RepoAgentIndex.md must not infer new agents. RepoAgentIndex.md must remain consistent with AGENTS.md. RepoAgentIndex.md must remain stable across agent cycles.

# END_OF_REPO_AGENT_INDEX
