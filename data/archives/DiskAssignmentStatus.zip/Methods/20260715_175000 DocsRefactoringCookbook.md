# MODULE: DocsRefactoringCookbook
# PURPOSE: Define the deterministic workflow for documentation refactoring inside <repo>.DocPhase using VS Code Chat Instructions. This cook-book references external terminology and Step 1 and Step 2 definitions stored in Methods\CookBooks.
# PATH: Methods\CookBooks\20260715_175000 DocsRefactoringCookbook.md
# VERSION: 1.2.0
# CHANGELOG:
# - 1.2.0 Updated references to timestamped Step 1 and Step 2 documents.
# - 1.2.0 Updated terminology references to DRC_Terminology.md.
# - 1.2.0 Updated approval model to include manually modified files.
# - 1.2.0 Removed conversational labels and replaced them with stable terminology references.
# - 1.2.0 Updated Phase 1 to reference external Step 1 and Step 2 documents.

# SECTION: OVERVIEW
Documentation refactoring is performed inside <repo>.DocPhase. All edits are executed by VS Code Copilot Chat using deterministic instructions derived from Step 1 issues and Step 2 corrections. Step 1 issues are defined in Methods\CookBooks\20240715_174000 Step1_DiscrepancyDomain.md. Step 2 corrections are defined in Methods\CookBooks\20240715_174000 Step2_CorrectionDomain.md. Terminology required for this cook-book is defined in Methods\CookBooks\DRC_Terminology.md. All changes undergo human verification before commit. Promotion back to <repo> occurs only after successful completion.

# SECTION: GLOBAL_RULES
All edits must remain within the Step 1 issue domain defined in Methods\CookBooks\20240715_174000 Step1_DiscrepancyDomain.md. All corrections must follow Step 2 methods defined in Methods\CookBooks\20240715_174000 Step2_CorrectionDomain.md. No regeneration is permitted. No drift is permitted. No edits outside documentation. No edits outside DocPhase. All changes must be human-verified before commit. Promotion only after ACTION_QUEUE.md marks the step DONE.

# SECTION: CONTROLLED_MULTI_FILE_REFACTORING
Controlled multi-file refactoring is defined in Methods\CookBooks\DRC_Terminology.md. VS Code may refactor multiple files in one instruction. All edits must remain within Step 1 issue scope and follow Step 2 corrections.

# SECTION: BATCH_LIMIT_RULE
The batch-limit rule is defined in Methods\CookBooks\DRC_Terminology.md. VS Code may modify up to the configured batch limit of files per instruction. If more files require changes than the batch limit, VS Code must propose a split. User may approve continuation to the next batch. Each batch must remain within Step 1 issue scope.

# SECTION: APPROVAL_MODEL
Approval uses the Human-Verified Commit model defined in Methods\CookBooks\DRC_Terminology.md. VS Code Chat applies refactoring edits to editor buffers. User manually verifies each file. User decides keep, keep with manual edit, or undo. VS Code stages and commits only accepted or manually modified files. Rejected files are not committed. VS Code or user provides a list of accepted, rejected, and manually modified files. Manually modified files require selective Step 1 review and may require additional Step 2 corrections. This list determines whether the phase is complete or must be repeated.

# SECTION: FOUR_PHASES

# PHASE_1_AGENT_PREPARATION
Identify Step 1 issues using Methods\CookBooks\20240715_174000 Step1_DiscrepancyDomain.md. Map each issue to Step 2 corrections using Methods\CookBooks\20240715_174000 Step2_CorrectionDomain.md. Generate a VS Code Chat Instruction. Instruction must be deterministic, ASCII-only, and scoped to Step 1 issues. Instruction must support controlled multi-file refactoring with the batch-limit rule.

# PHASE_2_VSCODE_EXECUTION
User opens relevant files in VS Code. User pastes the VS Code Chat Instruction. VS Code applies edits across up to the batch-limit number of files. If more files require changes, VS Code proposes batch splitting. User may approve continuation.

# PHASE_3_VERIFICATION
User manually inspects each changed file. User decides keep, keep with manual edit, or undo. VS Code stages and commits only accepted or manually modified files. VS Code or user provides list of accepted, rejected, and manually modified files. If rejected or manually modified files exist, agent may need to be repeated.

# PHASE_4_COMPLETION
User updates Methods\ACTION_QUEUE.md to mark the step DONE. User creates a log file in logs\agent-runs documenting agent name, files modified, files rejected, files manually modified, deviations, and status DONE. User may promote changes from <repo>.DocPhase to <repo>.

# SECTION: VSCODE_CHAT_INSTRUCTION_TEMPLATE
You are operating inside <repo>.DocPhase. Apply controlled multi-file refactoring according to the following rules. Scope is limited to Step 1 issues defined in Methods\CookBooks\20240715_174000 Step1_DiscrepancyDomain.md. Corrections must follow Step 2 methods defined in Methods\CookBooks\20240715_174000 Step2_CorrectionDomain.md. No regeneration. No drift. No edits outside documentation. Use the batch-limit rule defined in Methods\CookBooks\DRC_Terminology.md.

Perform the following actions:
<AGENT-SPECIFIC-ACTIONS>

After applying edits:
Present all changed files. Allow me to manually verify each file. I will decide keep, keep-with-manual-edit, or undo. Stage and commit only accepted or manually modified files. Provide a list of accepted, rejected, and manually modified files.

Do not commit rejected files. Do not introduce new content beyond Step 2 corrections.

# SECTION: AGENT_STRUCTURE
Agents must follow this structure.

# MODULE: <module-name>
# PURPOSE: <purpose>
# PATH: agents\<module-name>.md
# VERSION: <version>
# CHANGELOG:
<entries>

# SECTION: SCOPE
<scope>

# SECTION: TARGET_FILES
<files>

# SECTION: ACTIONS
<actions>

# SECTION: CHAT_INSTRUCTION
<instruction-template-filled>

# SECTION: LOGGING
<logging-rules>

# SECTION: COMPLETION
<completion-rules>

# SECTION: LOGGING_RULES
Log files must be created in logs\agent-runs\<timestamp>-<module-name>-run.md. Log must contain agent name, files modified, files rejected, files manually modified, deviations, and status DONE.

# SECTION: PROMOTION_RULES
Promotion from <repo>.DocPhase to <repo> is allowed only when ACTION_QUEUE.md marks the step DONE, log file exists, all changes are verified, no rejected files remain, manually modified files have been reviewed for selective Step 1 issues and corrected via Step 2 if required, no drift is detected, and no regeneration occurred.

# SECTION: EXAMPLE
You are operating inside <repo>.DocPhase. Fix Step 1 issues in Docs\Architecture.md and related module docs using definitions in Methods\CookBooks\20240715_174000 Step1_DiscrepancyDomain.md. Apply Step 2 corrections using Methods\CookBooks\20240715_174000 Step2_CorrectionDomain.md. Use the batch-limit rule defined in Methods\CookBooks\DRC_Terminology.md.

Actions:
Normalize headers. Correct outdated paths. Remove regeneration references. Align terminology with repository structure documentation. Ensure module boundaries match canonical definitions.

After edits:
Present changed files. I will verify each file. Stage and commit only accepted or manually modified files. Provide list of accepted, rejected, and manually modified files.

# END_OF_COOKBOOK
