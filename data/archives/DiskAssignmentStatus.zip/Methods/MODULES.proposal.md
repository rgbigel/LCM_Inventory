## Issue: Local logging orchestration is incorrectly classified as a module
Location: Modules.proposal.md

RequiredChange:
Remove the “Local logging orchestration” module definition. Reclassify this behavior as an Implementation.md note describing legacy fallback logging behavior. Ensure that SharedModules LoggingContext is documented as the authoritative logging mechanism.

Reason:
Local logging fallback is a repo-specific implementation detail, not a deterministic pipeline-level module. It must not appear in MODULES.md.

Status: dontdoit

## Issue: Private path fallback management is incorrectly classified as a module
Location: Modules.proposal.md

RequiredChange:
Remove the “Private path fallback management” module definition. Reclassify this behavior as an Implementation.md note describing legacy fallback path resolution. Ensure that SharedModules PrivatePaths is documented as the authoritative path provider.

Reason:
Private path fallback is a repo-specific implementation detail, not a deterministic pipeline-level module. It must not appear in MODULES.md.

Status: dontdoit
