# DOX Execution Lock

Copilot MUST NOT perform any refactoring, regeneration, rewriting, or file creation
unless the lock is explicitly set to "UNLOCKED".

Current state: LOCKED

Allowed actions: 
- Analysis only
- Summaries only
- Extraction proposals only
- No file writes
