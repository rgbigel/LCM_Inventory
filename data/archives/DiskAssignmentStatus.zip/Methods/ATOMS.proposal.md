# ATOMS.proposal.md — Version 3.2.0
# Layer: Regeneration (Repo-Specific Atomic Plane)
# ascii-only, deterministic-structure

## 1. PURPOSE
Capture repo-specific atomic responsibilities that do not generalize across repositories.
Store atoms that belong only to DiskAssignmentStatus and must not be added to ATOMS.md.
Provide deterministic atomic entries for regeneration planning, documentation alignment, and Organization indexing.

## 2. RULES
Pipeline-level atoms belong in ATOMS.md.
Repo-specific atoms belong in ATOMS.proposal.md.
Atoms must be:
  - deterministic
  - indivisible
  - non-inferential
  - reproducible
  - context-free
  - proposal-only until approved
ExecutionLock.State must be LOCKED before modification.

## 3. REPO-SPECIFIC ATOMS (FLAT FORMAT)

Atom: SharedModulesLoggingContextInitialization
Responsibility: Initialize shared logging context for DiskAssignmentStatus only.
Inputs: script name, version, EnableLogging, EnableTrace, InteractiveMode, NonInteractive, RepositoryRoot.
Outputs: initialized logging context for local execution.
Boundaries: must not generalize; must not modify SharedModules; must not infer global behavior.
Reason: local logging wrappers require removal and replacement with SharedModules logging.

Atom: LocalFallbackWriterRemoval
Responsibility: Identify and remove legacy fallback writer logic in DiskAssignmentStatus.
Inputs: Source/DiskAssignmentStatus.ps1, local Write-RunLog, local Write-TraceLog.
Outputs: proposal to remove fallback writer and adopt SharedModules logging lifecycle.
Boundaries: repo-specific; must not affect other repositories.
Reason: fallback writer is deprecated and violates documentation-plane constraints.

Atom: LocalPathResolutionCleanup
Responsibility: Remove legacy path resolution logic in DiskAssignmentStatus.
Inputs: local path resolution code, PrivatePaths.psm1 requirements.
Outputs: proposal to adopt SharedModules PrivatePaths resolution.
Boundaries: repo-specific; must not modify SharedModules.
Reason: local path logic duplicates SharedModules behavior.

Atom: RepoSpecificRecoveryEvaluationAlignment
Responsibility: Align recovery evaluation logic with Requirements.md for DiskAssignmentStatus only.
Inputs: path name keys and default values.
Outputs: resolved absolute path values.
Inputs: RecoveryEvaluation.psm1, Requirements.md recovery rules.
Outputs: proposal to correct repo-specific recovery evaluation behavior.
Boundaries: repo-specific; must not generalize.
Reason: DiskAssignmentStatus contains local recovery logic not present in other repos.

Atom: RepoSpecificJSONStateNormalization
Responsibility: Normalize JSON fields according to repo-specific requirements.
Inputs: JSONState.psm1, Requirements.md JSON rules.
Outputs: proposal to correct JSON normalization for DiskAssignmentStatus.
Boundaries: repo-specific; must not generalize.
Reason: JSON normalization differs across repos.

## 4. BOUNDARIES
ATOMS.proposal.md must not contain pipeline-level atoms.
ATOMS.proposal.md must not contain SharedModules atoms.
ATOMS.proposal.md must not contain module definitions.
ATOMS.proposal.md must not modify documentation-plane files.
ATOMS.proposal.md must not infer new atoms.

