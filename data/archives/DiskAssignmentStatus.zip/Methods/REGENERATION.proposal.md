# REGENERATION.proposal — Version 2.2.0
# Timestamp: 2026-07-12 10:24 CEST

## 1. Purpose
Capture repository-specific regeneration tasks that do not generalize across repos and therefore must not be added to REGENERATION.md. These tasks include cleanup of legacy behavior, documentation alignment, fallback removal, and local feature planning. All items must use Status fields to indicate current decision state.

## 2. Inputs
- DiskAssignmentStatus.AGENTS.md
- docs/Architecture.md
- docs/Implementation.md
- README.md
- DOC_ALIGNMENT.proposal.md
- MODULES.proposal.md
- ATOMS.proposal.md
- Required run-log and trace-log behavior
- Required fallback writer semantics
- Required transcript lifecycle behavior
- Requirements.md future feature claims

## 3. Repo-Specific Regeneration Tasks

## Task: Implement required run-log and trace-log behavior using SharedModules logging
Location: Source/DiskAssignmentStatus.ps1
RequiredChange: Implement the required “produce a run log” and “produce a trace log” behaviors using SharedModules LoggingContext. Ensure that -LogMode and -TraceMode flags activate SharedModules logging lifecycle correctly. Document fallback writer semantics in Implementation.md as required behavior, not as legacy wrappers.
Reason: Run-log and trace-log production are required functional behaviors of DiskAssignmentStatus. These behaviors must be implemented through SharedModules logging rather than local wrapper functions. The proposal must reflect required functionality, not cleanup.
Status: donow

---

## Task: Remove hard-coded fallback path values
Location: Source/DiskAssignmentStatus.ps1
RequiredChange: Remove repository-specific hard-coded default path values for GitRepositoriesRoot, BootOpsHubRoot, and TempRoot. Use SharedModules PrivatePaths exclusively.
Reason: Fallback values are local implementation details and must not appear in pipeline-level regeneration.
Status: donow

---

## Task: Document interactive transcript behavior
Location: docs/Implementation.md
RequiredChange: Document how DiskAssignmentStatus behaves when run interactively, including how SharedModules LoggingContext and TranscriptTools produce live trace output when -TraceMode or interactive execution is enabled. Clarify transcript start/stop lifecycle and fallback writer semantics.
Reason: Interactive transcript behavior is required functionality but is repository-specific. It must be documented in Implementation.md and must not be added to pipeline-level regeneration rules.
Status: dolater

---

## Task: Align Architecture.md, Implementation.md, and README.md with SharedModules integration
Location: docs/Architecture.md, docs/Implementation.md, README.md
RequiredChange: Update documentation to describe SharedModules LoggingContext and PrivatePaths usage, remove outdated fallback claims, and correct output mode statements.
Reason: Documentation alignment is repo-specific and must remain proposal-level.
Status: donow

---

## Task: Correct DiskAssignmentStatus.AGENTS.md authoritative references
Location: DiskAssignmentStatus.AGENTS.md
RequiredChange: Update authoritative documentation references to use the correct repository name “DiskAssignmentStatus” everywhere. Replace the nonexistent docs/README.md reference with the actual root README.md. Ensure separator lines use single-line separators only.
Reason: Agent metadata must reference the correct repository name and valid documentation paths. Multi-line separators introduce drift and must be removed.
Status: donow

---

## Task: Treat future “-Json” and “-Verbose” semantics as proposal work
Location: docs/Requirements.md
RequiredChange: Document that JSON output and verbose mode are future enhancements; keep Requirements.md authoritative by distinguishing implemented behavior from planned features.
Reason: These semantics are specific to DiskAssignmentStatus roadmap planning and must remain proposal-level.
Status: dontdoit

## 4. Outputs
- REGENERATION.proposal.md (this file)
- Repo-specific cleanup plan
- Documentation alignment plan
- Fallback removal plan
- Logging and transcript behavior plan
- Agent metadata correction plan
- Future feature planning notes

## 5. Completion Criteria
Proposal complete when:
- all repo-specific cleanup tasks are captured
- documentation drift is fully enumerated
- fallback logic removal is planned
- required logging and transcript behavior is documented
- agent metadata corrections are defined
- future feature semantics are isolated from pipeline-level regeneration
