# MODULE: DRC_Terminology
# PURPOSE: Define stable terminology for documentation refactoring inside <repo>.DocPhase. This file provides canonical definitions referenced by DocsRefactoringCookbook and other procedural documents.
# PATH: Methods\CookBooks\DRC_Terminology.md
# VERSION: 1.0.0
# CHANGELOG:
# - 1.0.0 Initial terminology definition for controlled documentation refactoring.

# SECTION: STEP1_ISSUE_DOMAIN
Step 1 issues are the discrepancies identified between documentation and repository reality. They are defined in Methods\CookBooks\20240714 Copilot Analysis.md. Step 1 issues describe mismatches in structure, behavior, architecture, terminology, workflows, or cross-repo integration. Step 1 issues define the scope of allowed refactoring actions.

# SECTION: STEP2_CORRECTION_DOMAIN
Step 2 corrections are the deterministic methods used to resolve Step 1 issues. They are defined in Methods\CookBooks\20240714 Copilot Analysis.md. Step 2 corrections specify how documentation and repository structure must be aligned. Step 2 corrections must be applied without regeneration and without drift.

# SECTION: CONTROLLED_MULTI_FILE_REFACTORING
Controlled multi-file refactoring is the process of applying deterministic documentation edits across multiple files in a single VS Code Chat Instruction. The scope of edits must remain within the Step 1 issue domain. All edits must follow Step 2 corrections. Controlled multi-file refactoring must not introduce new content beyond Step 2.

# SECTION: BATCH_LIMIT_RULE
The batch-limit rule defines the maximum number of files that may be modified in a single refactoring instruction. The default batch limit is ten files. If more files require changes, VS Code must propose a split into multiple batches. User may approve continuation to the next batch. Each batch must remain within Step 1 issue scope.

# SECTION: HUMAN_VERIFIED_COMMIT
Human-Verified Commit is the approval model for documentation refactoring. VS Code applies edits to editor buffers. User manually verifies each file. User decides keep, keep with manual edit, or undo. VS Code stages and commits only accepted or manually modified files. Rejected files are not committed. Manually modified files require selective Step 1 review and may require additional Step 2 corrections. A list of accepted, rejected, and manually modified files must be produced.

# SECTION: DISCREPANCY_TABLE
The discrepancy table is the mapping between documentation and repository reality. It is defined in Methods\CookBooks\20240714 Copilot Analysis.md. Each entry contains the documented expectation, the actual repository state, and the status of alignment. All refactoring actions must reduce discrepancies.

# SECTION: AGENT_CYCLE
The agent cycle is the controlled loop for refactoring. It consists of planning, applying changes, comparing results, adjusting documentation, and stabilizing. The agent cycle ensures that documentation and repository remain aligned after each refactoring step. The agent cycle is defined in Methods\CookBooks\20240714 Copilot Analysis.md.

# SECTION: DOCPHASE
DocPhase is the isolated workspace where documentation refactoring occurs. All edits must be performed inside <repo>.DocPhase. No edits may be applied directly to <repo>. Promotion from DocPhase to <repo> occurs only after verification and completion.

# SECTION: PROMOTION
Promotion is the controlled process of copying verified documentation changes from <repo>.DocPhase to <repo>. Promotion is allowed only when the agent cycle is complete, ACTION_QUEUE.md marks the step DONE, and all files have passed Human-Verified Commit. No rejected files may remain. Manually modified files must be fully resolved.

# SECTION: NON_REGENERATION_RULE
The non-regeneration rule forbids automatic regeneration of documentation from any source. Documentation must be corrected manually using Step 2 methods. Regeneration is not permitted until discrepancies are reduced to a known and manageable set.

# SECTION: SCOPE_RESTRICTION
Scope restriction ensures that refactoring actions remain within the Step 1 issue domain. No edits may be applied outside the defined discrepancy areas. No edits may be applied to unrelated documentation. No edits may be applied to code.

# SECTION: MANUAL_MODIFICATION_REVIEW
Manual modification review is required for any file that the user modifies manually during verification. These files must be checked for selective Step 1 issues and corrected using Step 2 methods if required. Manual modifications must be included in the final list of accepted, rejected, and manually modified files.

# END OF TERMINOLOGY
