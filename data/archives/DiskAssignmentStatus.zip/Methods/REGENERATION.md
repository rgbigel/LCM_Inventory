# REGENERATION — Version 2.0.0

## 1. Purpose
Define deterministic regeneration steps required to align DiskAssignmentStatus with:
- ATOMS.md Version 2.0.0
- MODULES.md Version 2.0.0
- ACTIONS.md Version 2.0.0
- SharedModules logging, path, and versioning atoms
- Recovery evaluation atoms
- JSON-state pipeline atoms
- Documentation alignment requirements

## 2. Inputs
ATOMS.md  
MODULES.md  
ACTIONS.md  
DOC_SYNC.md  
DiskAssignment.AGENTS.md  
SharedModules (authoritative)

## 3. Deterministic Regeneration Steps

### Step: Adopt deterministic atoms for discovery, evaluation, and reporting
Responsibility: Implement the four pipeline-level atoms in the local module architecture.
Inputs: ATOMS.md definitions, module boundaries, discovery/evaluation/reporting requirements.
Outputs: atom-aligned local modules and code organization.
Boundaries: Pipeline-level atom adoption; must not include repo-specific helper implementations.
Reason: These atoms define stable, repeatable constructs required by the regeneration pipeline.

### Step: Implement recovery evaluation atoms
Responsibility: Add deterministic recovery evaluation logic for:
- HasValidWinRE
- HasRecoveryPartition
- PartitionLayoutStatus
- RequiresFix
- RecommendedAction
Inputs: discovery output, WinRE mapping facts, recovery partition metadata, partition layout analysis.
Outputs: structured recovery evaluation object aligned with ATOMS.md and MODULES.md.
Boundaries: Pipeline-level evaluation behavior; must not include reporting or JSON emission.
Reason: Recovery evaluation is a reusable, cross-repository evaluation submodule.

### Step: Implement JSON-state pipeline
Responsibility: Build, normalize, validate, serialize, stamp, merge, and emit deterministic JSON state.
Inputs: discovery output, evaluation output, recovery inference output, SharedModules PrivatePaths, version metadata.
Outputs: deterministic state model, validated JSON payload, versioned JSON file emission.
Boundaries: Pipeline-level JSON-state behavior; independent of reporting formatting.
Reason: JSON-state persistence is a repeatable pipeline construct with clear completion criteria.

### Step: Align logging and trace behavior with SharedModules
Responsibility: Replace outdated local logging wrappers and fallback writer logic.
Inputs: SharedModules LoggingContext, SharedModules TraceContext.
Outputs: consistent logging and trace behavior.
Boundaries: Must not reintroduce local fallback writers.
Reason: SharedModules defines authoritative logging behavior.

### Step: Align private path resolution with SharedModules
Responsibility: Replace local path resolution logic with SharedModules PrivatePaths.
Inputs: SharedModules PrivatePaths.
Outputs: deterministic path resolution for logs, JSON output, and audit artifacts.
Boundaries: Must not use local fallback paths.
Reason: SharedModules defines authoritative path resolution.

### Step: Align documentation with updated architecture
Responsibility: Update Architecture.md, Implementation.md, README.md to remove outdated logging, fallback writer, and output mode claims.
Inputs: DOC_SYNC.md drift report.
Outputs: aligned documentation plane.
Boundaries: Must not weaken Requirements.md.
Reason: Documentation must reflect the regenerated architecture.

### Step: Align parameter contract with Requirements.md
Responsibility: Ensure supported parameters match Requirements.md.
Inputs: Requirements.md, parameter block.
Outputs: aligned parameter block.
Boundaries: Must not remove future parameters such as -Json.
Reason: Parameter contract must be deterministic and documented.

### Step: Align module stubs with MODULES.md v2.0.0
Responsibility: Ensure module directories and stubs exist for:
- Discovery
- Evaluation
- Reporting
- RecoveryEvaluation
- JSONState
Inputs: MODULES.md.
Outputs: aligned module structure.
Boundaries: Must not introduce repo-specific modules.
Reason: Module structure must match authoritative definitions.

### Step: Align script header with authoritative header rules
Responsibility: Ensure script header fields match stored ExplicitFacts.
Inputs: ExplicitFacts, script header.
Outputs: aligned script header.
Boundaries: Must not omit required fields.
Reason: Header alignment is required for deterministic regeneration.

### Step: Align deterministic orchestration
Responsibility: Ensure orchestration follows atom → module → action → output flow.
Inputs: ATOMS.md, MODULES.md, ACTIONS.md.
Outputs: aligned orchestration.
Boundaries: Must not introduce undocumented behavior.
Reason: Deterministic orchestration is required for regeneration.

### Step: Produce patch proposals
Responsibility: Generate patch proposals for all required regeneration steps.
Inputs: regeneration plan.
Outputs: patch proposal set.
Boundaries: Must not modify SharedModules.
Reason: Patch proposals complete the regeneration cycle.

## 4. Outputs
REGENERATION.md  
REGENERATION.proposal.md  
Patch proposal set  
Aligned documentation plane  
Aligned module structure  
Aligned orchestration  
Aligned logging and path integration  
Aligned recovery evaluation  
Aligned JSON-state pipeline

## 5. Completion Criteria
Regeneration complete when:
- deterministic atoms adopted
- recovery evaluation implemented
- JSON-state pipeline implemented
- SharedModules integration aligned
- documentation aligned
- module structure aligned
- parameter contract aligned
- orchestration aligned
- patch proposals generated
