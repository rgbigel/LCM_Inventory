# MODULE: 012-CommitAndPush.Bundle
# PURPOSE: Bundled instruction block for VS Code Chat to stage, commit, and push all verified-but-uncommitted changes in DiskAssignmentStatus_AC.
# PATH: agent-tools\012-CommitAndPush.Bundle.md
# AUTHORS: Rolf
# VERSION: 1.0.0
# CHANGELOG:
# - 1.0.0 Initial generalized commit/push bundle.

# EXECUTION CONTEXT
Workspace must be:
D:\Git_Repositories\DiskAssignmentStatus_AC

Confirm before staging or committing.

# INSTRUCTION BLOCK FOR VS CODE CHAT

# PHASE 1 — COLLECT OPEN CHANGES
Identify all files with verified-but-uncommitted modifications.
List them explicitly.
Do not stage yet.

# PHASE 2 — FINAL REVIEW
Show a combined diff of all open changes.
Ensure:
- All changes belong to verified agent cycles.
- No unrelated edits are present.
- No regeneration artifacts are present.
- No boundary or structural drift occurred.

Wait for my approval.

# PHASE 3 — STAGE
Stage all verified files.
Do not commit yet.

# PHASE 4 — COMMIT
Create a commit with the following deterministic message:

"DocPhase: apply verified agent-cycle updates and index synchronization."

Do not push yet.

# PHASE 5 — PUSH
Push the commit to the current branch.
Wait for confirmation of success.

# PHASE 6 — REPORT
Show:
- Commit hash
- Branch name
- List of committed files
