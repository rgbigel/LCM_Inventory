# MODULE: 002-LocalFallbackWriterRemoval.Verify
# PURPOSE: Verification instruction block for VS Code Chat after executing LocalFallbackWriterRemoval.
# PATH: agent-tools\002-LocalFallbackWriterRemoval.Verify.md
# AUTHORS: Rolf
# VERSION: 1.0.0
# CHANGELOG:
# - 1.0.0 Initial verification block.

# INSTRUCTION BLOCK FOR VS CODE CHAT
Show me a diff of the following files:

- Docs/Logging.md
- Docs/CrossLayerFlowDiagram.md
- Docs/Implementation.md

Verify that:
- All fallback writer references are removed.
- All replacements reference "SharedModules logging lifecycle".
- No unrelated lines changed.
- No structural changes occurred.

Do not stage or commit anything.
Wait for my explicit approval.
