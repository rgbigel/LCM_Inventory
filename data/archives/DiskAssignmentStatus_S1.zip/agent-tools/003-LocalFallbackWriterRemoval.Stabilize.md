# MODULE: 003-LocalFallbackWriterRemoval.Stabilize
# PURPOSE: Stabilization instruction block for VS Code Chat after verification of LocalFallbackWriterRemoval.
# PATH: agent-tools\003-LocalFallbackWriterRemoval.Stabilize.md
# AUTHORS: Rolf
# VERSION: 1.0.0
# CHANGELOG:
# - 1.0.0 Initial stabilization block.

# INSTRUCTION BLOCK FOR VS CODE CHAT
If verification is approved, apply stabilization:

- Ensure no structural changes were introduced.
- Ensure no regeneration is required.
- Ensure no module boundary changes occurred.
- Ensure no JSON or recovery evaluation logic was affected.

After stabilization, show me the final diff.
Do not stage or commit anything until I approve.
