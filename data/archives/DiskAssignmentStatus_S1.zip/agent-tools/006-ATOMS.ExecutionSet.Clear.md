# MODULE: 006-ATOMS.ExecutionSet.Clear
# PURPOSE: Instruction block for VS Code Chat to clear ATOMS.ExecutionSet.md after LocalFallbackWriterRemoval completion.
# PATH: agent-tools\006-ATOMS.ExecutionSet.Clear.md
# AUTHORS: Rolf
# VERSION: 1.0.0
# CHANGELOG:
# - 1.0.0 Initial ATOMS.ExecutionSet clear block.

# INSTRUCTION BLOCK FOR VS CODE CHAT
Open the file:
- Methods/ATOMS.ExecutionSet.md

Apply the following deterministic update:
- Remove all atoms from the execution set.
- Leave the file structure intact.
- Leave timestamps intact.
- Do not infer new atoms.
- Do not modify other sections.

After applying the update, show me the full diff for verification.
Do not stage or commit anything until I approve.
