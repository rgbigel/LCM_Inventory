# MODULE: 009-RepoAgentIndex.Verify
# PURPOSE: Verification instruction block for VS Code Chat after updating RepoAgentIndex.md.
# PATH: agent-tools\009-RepoAgentIndex.Verify.md
# AUTHORS: Rolf
# VERSION: 1.0.0
# CHANGELOG:
# - 1.0.0 Initial RepoAgentIndex verification block.

# INSTRUCTION BLOCK FOR VS CODE CHAT
Open the file:
- Methods/RepoAgentIndex.md

Verify that:
- The agent LocalLoggingCleanup is present.
- The atom LocalFallbackWriterRemoval is referenced correctly.
- No new agents were added.
- No agents were removed.
- No boundaries were modified.
- No unrelated sections were changed.

Show me the full diff for verification.
Do not stage or commit anything until I approve.
