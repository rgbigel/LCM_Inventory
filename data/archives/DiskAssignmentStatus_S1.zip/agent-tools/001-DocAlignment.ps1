param()

<#
Module: 001-DocAlignment.ps1
Purpose: Hybrid documentation alignment executor (Discovery -> Evaluation -> Reporting -> ACTIONS -> Pipeline)
Authors: Rolf
Version: 2.1.0
Path: D:\Git_Repositories\DiskAssignmentStatus_AC\agent-tools\001-DocAlignment.ps1
Changelog:
  - ASCII-only script body
  - Fixed Join-Path array construction
  - Added ACTIONS.md / AGENTS / WorkspaceAgentIndex / DocContext inspection
  - Added CrossRepo.proposals.md presence check
  - Deterministic StabilizationLog append
  - Doc-only Pipeline (no code changes)
#>

# Workspace paths
$repoRoot    = 'D:\Git_Repositories\DiskAssignmentStatus_AC'
$logDir      = Join-Path $repoRoot 'logs\agent-runs'
$logFile     = Join-Path $logDir 'DiskAssignmentStatus.StabilizationLog.md'
$actionsFile = Join-Path $repoRoot 'ACTIONS.md'
$agentsFile  = Join-Path $repoRoot 'DiskAssignment.AGENTS.md'
$contextFile = Join-Path $repoRoot 'DocContext.json'
$wsIndexFile = Join-Path $repoRoot 'WorkspaceAgentIndex.md'
$crossRepo   = Join-Path $repoRoot 'docs\CrossRepo.proposals.md'

# Ensure log directory exists
if (-not (Test-Path $logDir)) {
  New-Item -ItemType Directory -Path $logDir | Out-Null
}

# Timestamp
$ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')

# Documentation plane
$docs = @()
$docs += (Join-Path $repoRoot 'docs\Architecture.md')
$docs += (Join-Path $repoRoot 'docs\Requirements.md')
$docs += (Join-Path $repoRoot 'docs\Implementation.md')
$docs += (Join-Path $repoRoot 'README.md')

# Module structure
$modules = @()
$modules += (Join-Path $repoRoot 'Modules\Discovery')
$modules += (Join-Path $repoRoot 'Modules\Evaluation')
$modules += (Join-Path $repoRoot 'Modules\Reporting')
$modules += (Join-Path $repoRoot 'Modules\RecoveryEvaluation')
$modules += (Join-Path $repoRoot 'Modules\JSONState')

# Begin log entry
$entry = @()
$entry += ("## DocAlignment Run - " + $ts)
$entry += ""
$entry += "### Discovery"

# Core control files
if (Test-Path $actionsFile) {
  $entry += ("- OK: ACTIONS.md present at " + $actionsFile)
} else {
  $entry += ("- Missing: ACTIONS.md at " + $actionsFile)
}

if (Test-Path $agentsFile) {
  $entry += ("- OK: DiskAssignment.AGENTS.md present at " + $agentsFile)
} else {
  $entry += ("- Missing: DiskAssignment.AGENTS.md at " + $agentsFile)
}

if (Test-Path $wsIndexFile) {
  $entry += ("- OK: WorkspaceAgentIndex.md present at " + $wsIndexFile)
} else {
  $entry += ("- Missing: WorkspaceAgentIndex.md at " + $wsIndexFile)
}

if (Test-Path $contextFile) {
  $entry += ("- OK: DocContext.json present at " + $contextFile)
} else {
  $entry += ("- Missing: DocContext.json at " + $contextFile)
}

# CrossRepo proposals file
if (Test-Path $crossRepo) {
  $entry += ("- OK: CrossRepo.proposals.md present at " + $crossRepo)
} else {
  $entry += ("- Missing: CrossRepo.proposals.md at " + $crossRepo)
}

$entry += "- Scanned documentation plane"
$entry += "- Scanned module structure"
$entry += ""

# Discovery: documentation plane
foreach ($doc in $docs) {
  if (Test-Path $doc) {
    $entry += ("- OK: " + $doc)
  }
  else {
    $entry += ("- Missing: " + $doc)
  }
}

# Discovery: modules
foreach ($m in $modules) {
  if (Test-Path $m) {
    $entry += ("- OK: " + $m)
  }
  else {
    $entry += ("- Missing: " + $m)
  }
}

$entry += ""
$entry += "### Evaluation"

# Evaluate documentation alignment
foreach ($doc in $docs) {
  if (Test-Path $doc) {
    $content = Get-Content $doc -Raw
    if ($content.Length -gt 0) {
      $entry += ("- OK: " + $doc + " content present")
    }
    else {
      $entry += ("- Drift: " + $doc + " is empty")
    }
  }
}

# Evaluate module directories
foreach ($m in $modules) {
  if (Test-Path $m) {
    $files = Get-ChildItem $m -File -ErrorAction SilentlyContinue
    if ($files.Count -gt 0) {
      $entry += ("- OK: " + $m + " contains module files")
    }
    else {
      $entry += ("- Drift: " + $m + " contains no module files")
    }
  }
}

# Basic inspection of ACTIONS.md for methodology chain
if (Test-Path $actionsFile) {
  $actionsContent = Get-Content $actionsFile -Raw
  $hasChain = ($actionsContent -like "*Discovery*" -and
               $actionsContent -like "*Evaluation*" -and
               $actionsContent -like "*Reporting*" -and
               $actionsContent -like "*ACTIONS*" -and
               $actionsContent -like "*Pipeline*")
  if ($hasChain) {
    $entry += "- OK: ACTIONS.md contains Discovery -> Evaluation -> Reporting -> ACTIONS -> Pipeline chain"
  } else {
    $entry += "- Drift: ACTIONS.md does not clearly contain the full methodology chain"
  }
}

$entry += ""
$entry += "### Reporting"
$entry += "- Writing findings to StabilizationLog"
$entry += ""

# ACTIONS proposals (doc-only)
$entry += "### ACTIONS (Proposals)"
$entry += "- Propose documentation alignment based on presence and content checks"
$entry += "- Propose missing section insertion where docs are empty or missing"
$entry += "- Propose consistency fixes between ACTIONS.md and StabilizationPlan"
$entry += "- Propose SharedModules promotion candidates (documentation only, to CrossRepo.proposals.md)"
$entry += "- No code changes proposed"
$entry += ""

# Pipeline (doc-only)
$entry += "### Pipeline (Doc-Only)"
$entry += "- Apply accepted documentation edits only (manual review required)"
$entry += "- Write cross-repo proposals to docs/CrossRepo.proposals.md (if present or created separately)"
$entry += "- No code regeneration performed"
$entry += ""

# Append to log
Add-Content -Path $logFile -Value ($entry -join "`n")
