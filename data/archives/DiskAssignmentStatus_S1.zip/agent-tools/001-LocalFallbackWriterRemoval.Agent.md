# MODULE: 001-LocalFallbackWriterRemoval.Agent
# PURPOSE: Instruction block for VS Code Chat to execute the LocalFallbackWriterRemoval agent safely inside DiskAssignmentStatus_AC.
# PATH: agent-tools\001-LocalFallbackWriterRemoval.Agent.md
# AUTHORS: Rolf
# VERSION: 1.0.0
# CHANGELOG:
# - 1.0.0 Initial VS Code Chat executor for LocalFallbackWriterRemoval.

# EXECUTION CONTEXT
We are working inside the repository:
D:\Git_Repositories\DiskAssignmentStatus_AC

Confirm the workspace folder path before applying any edits.
If the workspace is not DiskAssignmentStatus_AC, do not apply any changes.

# INSTRUCTION BLOCK FOR VS CODE CHAT
Apply the following deterministic documentation edits exactly as written.
Do not infer, expand, or optimize.
Do not modify any other lines.

TARGET FILES:
- Docs/Logging.md
- Docs/CrossLayerFlowDiagram.md
- Docs/Implementation.md

EDITS:
1. Remove all references to "local fallback writer".
2. Remove any fallback writer initialization sequence.
3. Remove any fallback writer flow or diagram element.
4. Replace removed references with: "SharedModules logging lifecycle".

After applying the edits, show me the full diff for verification.
Do not commit or stage any changes automatically.
Wait for my explicit approval after showing the diff.
