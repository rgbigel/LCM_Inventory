# MODULE: 010-RepoAgentIndex.Stabilize
# PURPOSE: Stabilization instruction block for VS Code Chat after verifying RepoAgentIndex.md.
# PATH: agent-tools\010-RepoAgentIndex.Stabilize.md
# AUTHORS: Rolf
# VERSION: 1.0.0
# CHANGELOG:
# - 1.0.0 Initial RepoAgentIndex stabilization block.

# INSTRUCTION BLOCK FOR VS CODE CHAT
Open the file:
- Methods/RepoAgentIndex.md

Apply stabilization:
- Ensure no structural changes were introduced.
- Ensure no regeneration is required.
- Ensure no module boundaries were modified.
- Ensure no terminology drift occurred.
- Ensure no unrelated sections were affected.

After stabilization, show me the final diff.
Do not stage or commit anything until I approve.
