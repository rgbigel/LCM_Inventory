# MODULE: 007-ATOMS.ExecutionSet.Verify
# PURPOSE: Verification instruction block for VS Code Chat after clearing ATOMS.ExecutionSet.md.
# PATH: agent-tools\007-ATOMS.ExecutionSet.Verify.md
# AUTHORS: Rolf
# VERSION: 1.0.0
# CHANGELOG:
# - 1.0.0 Initial ATOMS.ExecutionSet verification block.

# INSTRUCTION BLOCK FOR VS CODE CHAT
Open the file:
- Methods/ATOMS.ExecutionSet.md

Verify that:
- The execution set is empty.
- The file structure remains intact.
- No timestamps were modified.
- No atoms were added.
- No unrelated sections were changed.

Show me the full diff for verification.
Do not stage or commit anything until I approve.
