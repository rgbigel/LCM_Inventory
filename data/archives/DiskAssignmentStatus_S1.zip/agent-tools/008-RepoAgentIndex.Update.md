# MODULE: 008-RepoAgentIndex.Update
# PURPOSE: Instruction block for VS Code Chat to update RepoAgentIndex.md after LocalFallbackWriterRemoval completion.
# PATH: agent-tools\008-RepoAgentIndex.Update.md
# AUTHORS: Rolf
# VERSION: 1.0.0
# CHANGELOG:
# - 1.0.0 Initial RepoAgentIndex update block.

# INSTRUCTION BLOCK FOR VS CODE CHAT
Open the file:
- Methods/RepoAgentIndex.md

Apply the following deterministic update:
- Ensure the agent LocalLoggingCleanup remains listed.
- Ensure LocalFallbackWriterRemoval remains referenced as its atom.
- Do not add new agents.
- Do not remove existing agents.
- Do not modify boundaries.
- Do not infer new terminology.
- Do not modify unrelated sections.

After applying the update, show me the full diff for verification.
Do not stage or commit anything until I approve.
