# MODULE: 011-LocalFallbackWriterRemoval.Bundle
# PURPOSE: Bundled instruction block for VS Code Chat to execute, verify, stabilize, and prepare commit for LocalFallbackWriterRemoval.
# PATH: agent-tools\011-LocalFallbackWriterRemoval.Bundle.md
# AUTHORS: Rolf
# VERSION: 1.0.0
# CHANGELOG:
# - 1.0.0 Initial bundled agent executor.

# EXECUTION CONTEXT
Workspace must be:
D:\Git_Repositories\DiskAssignmentStatus.DocPhase

Confirm before applying any edits.

# INSTRUCTION BLOCK FOR VS CODE CHAT

# PHASE 1 — EXECUTE
Apply deterministic edits to:
- Docs/Logging.md
- Docs/CrossLayerFlowDiagram.md
- Docs/Implementation.md

Edits:
1. Remove all references to "local fallback writer".
2. Remove fallback writer initialization sequences.
3. Remove fallback writer flow or diagram elements.
4. Replace removed references with "SharedModules logging lifecycle".

Show full diff. Do not stage or commit.

# PHASE 2 — VERIFY
Verify:
- All fallback writer references removed.
- All replacements reference SharedModules logging lifecycle.
- No unrelated lines changed.
- No structural changes occurred.

Show verification diff. Do not stage or commit.

# PHASE 3 — STABILIZE
Stabilize:
- No structural changes introduced.
- No regeneration required.
- No module boundaries modified.
- No terminology drift.

Show stabilization diff. Do not stage or commit.

# PHASE 4 — UPDATE INDEXES
Apply deterministic updates to:
- Methods/ACTION_QUEUE.md
- Methods/ACTION_QUEUE.State.md
- Methods/ATOMS.ExecutionSet.md
- Methods/RepoAgentIndex.md

Rules:
- Set LocalLoggingCleanup state to DONE.
- Clear ATOMS.ExecutionSet.
- Ensure LocalFallbackWriterRemoval remains referenced.
- No new agents.
- No removed agents.
- No boundary changes.

Show diff. Do not stage or commit.

# PHASE 5 — PREPARE COMMIT
Bundle all open changes.
Prepare commit message:
"LocalFallbackWriterRemoval: removed fallback writer references, updated logging lifecycle, updated agent indexes."

Wait for my explicit approval before staging or committing.
